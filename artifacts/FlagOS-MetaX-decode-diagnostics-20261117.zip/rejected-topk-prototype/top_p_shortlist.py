"""Mass-certified nucleus shortlist; original full sort is the fallback.

No sampling parameter, temperature, RNG draw, or token probability is changed.
For top-p-only rows whose nucleus fits in a bounded shortlist, discarded-tail
probability precedes that shortlist in the original ascending cumulative sum.
Floating-point boundary uncertainty and split ties use the original algorithm.
The output retains the original logits verbatim, masking only rejected tokens.
"""
import torch

CAPACITY=4096
BOUNDARY_MARGIN=1e-5
STATS={'calls':0,'shortlist_rows':0,'fallback_rows':0}

def filter_logits(logits,k,p,native):
    STATS['calls']+=1
    if (k is not None or p is None or logits.ndim!=2 or logits.dtype!=torch.float32
        or not logits.is_cuda or logits.shape[1]<=CAPACITY):
        STATS['fallback_rows']+=logits.shape[0]
        return native(logits,k,p)
    values,ids=logits.topk(CAPACITY,dim=-1,largest=True,sorted=True)
    probs=logits.softmax(dim=-1)
    selected=probs.gather(1,ids)
    mass=selected.sum(dim=-1)
    asc_values=values.flip([-1]);asc_ids=ids.flip([-1])
    cumulative=selected.flip([-1]).cumsum(dim=-1)+(1.0-mass).unsqueeze(1)
    boundary=1-p.unsqueeze(1)
    masked=cumulative<=boundary
    masked[:,-1]=False
    split_tie=((asc_values[:,1:]==asc_values[:,:-1]) & (masked[:,1:]!=masked[:,:-1])).any(dim=-1)
    safe=((mass>p+BOUNDARY_MARGIN) & torch.isfinite(probs).all(dim=-1)
          & ((cumulative-boundary).abs().amin(dim=-1)>BOUNDARY_MARGIN) & ~split_tie)
    count=int(safe.sum().item())
    STATS['shortlist_rows']+=count
    STATS['fallback_rows']+=logits.shape[0]-count
    if count==0:
        return native(logits,k,p)
    fallback_ids=None;fallback_values=None
    if count!=logits.shape[0]:
        fallback_ids=(~safe).nonzero().flatten()
        fallback_values=native(logits.index_select(0,fallback_ids),None,p.index_select(0,fallback_ids))
    result_values=asc_values.masked_fill(masked,-float('inf'))
    logits.fill_(-float('inf'));logits.scatter_(1,asc_ids,result_values)
    if fallback_ids is not None:logits.index_copy_(0,fallback_ids,fallback_values)
    return logits
