#!/usr/bin/env python3
import csv
import hashlib
import json
import os
from pathlib import Path
import signal
import socket
import subprocess
import sys
import time
import urllib.request

ROOT = Path("/workspace/tokenforge-artifacts/iluvatar_v3_complete_20261109_0000")
SOURCE = Path("/workspace/tokenforge-sources/plugin-iluvatar-v3-20261108")
VERIFY = Path("/workspace/tokenforge-sources/flagos-minicpm-throughput-verify-20261108")
CACHE = Path("/workspace/tokenforge-caches/iluvatar_v3_complete_20261109_0000")
MODEL = Path("/workspace/MiniCPM5-2B")
BENCH = Path("/workspace/vllm-plugin-FL/benchmarks/benchmark_throughput_serve.py")
ACCURACY_SCRIPT = VERIFY / "tools/run_official_accuracy.sh"
AUDITOR = VERIFY / "tools/validate_accuracy_artifacts.py"
BASELINE = VERIFY / "results/2026-10-31-iluvatar-mixed-v2/independent-result.json"
EXPECTED_SOURCE_SHA = "6e57a2868affd9e3a5319b23300208cd3bb888f78881ea5f96b0a10c8967ee6a"
CUTOFF = 1794174900
ACCURACY_TIMEOUT = 3600
CLEANUP_RESERVE = 300
AUDIT_RESERVE = 180
REFS = {4096: (2028.01, 11573.53, 256), 16384: (915.15, 599262.03, 128)}
server = None
stop_requested = False

def now():
    return time.time()

def utc():
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())

def write_json(path, value):
    path = Path(path)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp, path)

def status(stage, **extra):
    value = {
        "session": ROOT.name,
        "updated_utc": utc(),
        "stage": stage,
        "hard_cutoff_epoch": CUTOFF,
        "server_pid": server.pid if server and server.poll() is None else None,
        **extra,
    }
    write_json(ROOT / "status.json", value)

def stop_group(proc, label):
    if proc is None:
        return
    try:
        os.killpg(proc.pid, signal.SIGTERM)
    except ProcessLookupError:
        return
    deadline = now() + 20
    while now() < deadline:
        if proc.poll() is None:
            try:
                proc.wait(timeout=0.25)
            except subprocess.TimeoutExpired:
                pass
        try:
            os.killpg(proc.pid, 0)
        except ProcessLookupError:
            return
        time.sleep(0.25)
    try:
        os.killpg(proc.pid, signal.SIGKILL)
    except ProcessLookupError:
        pass
    if proc.poll() is None:
        proc.wait(timeout=10)

def handle_signal(signum, frame):
    global stop_requested
    stop_requested = True
    raise KeyboardInterrupt(f"received signal {signum}")

signal.signal(signal.SIGTERM, handle_signal)
signal.signal(signal.SIGINT, handle_signal)

def request(path):
    with urllib.request.urlopen("http://127.0.0.1:9031" + path, timeout=5) as r:
        return json.loads(r.read())

def health_check():
    with urllib.request.urlopen("http://127.0.0.1:9031/health", timeout=5) as r:
        return r.status == 200

def ensure_paths():
    for path in (MODEL / "config.json", BENCH, ACCURACY_SCRIPT, AUDITOR, BASELINE):
        if not path.is_file():
            raise FileNotFoundError(path)
    actual = hashlib.sha256((SOURCE / "vllm_fl/dispatch/backends/vendor/iluvatar/impl/attention_tiles.py").read_bytes()).hexdigest()
    if actual != EXPECTED_SOURCE_SHA:
        raise RuntimeError(f"candidate source hash mismatch: {actual}")
    if now() + 2 * 60 * 60 + ACCURACY_TIMEOUT + AUDIT_RESERVE + CLEANUP_RESERVE >= CUTOFF:
        raise RuntimeError("insufficient reservation remains for benchmark, accuracy, and cleanup")
    if ROOT.joinpath("independent-result.json").exists():
        raise FileExistsError("immutable result already exists")
    with socket.socket() as sock:
        if sock.connect_ex(("127.0.0.1", 9031)) == 0:
            raise RuntimeError("port 9031 became occupied before candidate server launch")
    CACHE.mkdir(parents=True, exist_ok=True)
    (ROOT / "smoke").mkdir(exist_ok=True)
    (ROOT / "official-benchmark").mkdir(exist_ok=True)

def env_for(stage_root=None):
    env = dict(os.environ)
    env.update({
        "VLLM_PLUGINS": "fl",
        "PYTHONPATH": f"{SOURCE}:{VERIFY}",
        "FLAGOS_TILED_ATTN_MODE": "v3",
        "FLAGOS_SESSION_ROOT": str(ROOT),
        "TRITON_CACHE_DIR": str(CACHE),
        "FLAGOS_HARD_CUTOFF_EPOCH": str(CUTOFF),
        "CUDA_CACHE_PATH": str(CACHE / "cuda"),
    })
    if stage_root:
        env["FLAGOS_EVAL_WORK_DIR"] = str(stage_root)
    return env

def server_pids():
    import psutil
    result = set()
    try:
        root = psutil.Process(server.pid)
        result.add(root.pid)
        result.update(p.pid for p in root.children(recursive=True))
    except psutil.Error:
        pass
    return sorted(result)

def run_stage(name, argv, cwd, log_path, timeout, env):
    remaining = CUTOFF - now() - CLEANUP_RESERVE
    allowed = min(timeout, remaining)
    if allowed <= 0:
        raise TimeoutError(f"no time left to start {name}")
    with Path(log_path).open("w", encoding="utf-8") as log:
        proc = subprocess.Popen(argv, cwd=str(cwd), env=env, stdin=subprocess.DEVNULL,
                                stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        status(name, stage_pid=proc.pid, stage_timeout_seconds=allowed, stage_log=str(log_path))
        try:
            code = proc.wait(timeout=allowed)
        except subprocess.TimeoutExpired:
            stop_group(proc, name)
            raise TimeoutError(f"{name} exceeded its bounded window")
    if code != 0:
        raise subprocess.CalledProcessError(code, argv)
    return proc.pid

def validate_csv(csv_path, cases, smoke=False):
    with Path(csv_path).open(newline="", encoding="utf-8-sig") as f:
        rows = list(csv.DictReader(f))
    expected_rows = 8 if len(cases) == 2 else 4 * len(cases)
    if len(rows) != expected_rows:
        raise AssertionError(f"{csv_path}: expected {expected_rows} raw rows, got {len(rows)}")
    summaries = []
    for input_len, output_len, concurrency, requests_count in cases:
        group = [row for row in rows if int(row["Prefill"]) == input_len]
        if len(group) != 4:
            raise AssertionError(f"{input_len}: expected four rounds, got {len(group)}")
        for row in group:
            expected_in = input_len * requests_count
            expected_out = output_len * requests_count
            if row["Run Status"] != "SUCCESS":
                raise AssertionError(f"{input_len}: failed run {row}")
            if int(float(row["Successful Requests"])) != requests_count:
                raise AssertionError(f"{input_len}: successful request count mismatch")
            if int(float(row["Total Input Tokens"])) != expected_in or int(float(row["Total Output Tokens"])) != expected_out:
                raise AssertionError(f"{input_len}: token totals mismatch")
        scored = group[1:]
        tps = sum(float(r["Total tok/s"]) for r in scored) / 3
        ttft = sum(float(r["Mean TTFT (ms)"]) for r in scored) / 3
        item = {"input_len": input_len, "rounds": 4, "discarded_first": True,
                "requests_per_round": requests_count, "input_tokens_per_round": input_len * requests_count,
                "output_tokens_per_round": output_len * requests_count,
                "mean_total_tok_s_last3": tps, "mean_ttft_ms_last3": ttft}
        if not smoke:
            ref_tps, ref_ttft, _ = REFS[input_len]
            item.update({"reference_total_tok_s": ref_tps, "reference_ttft_ms": ref_ttft,
                         "throughput_ratio": tps / ref_tps, "ttft_ratio": ttft / ref_ttft,
                         "performance_pass": tps >= ref_tps * 0.99 and ttft <= ref_ttft * 1.01})
        summaries.append(item)
    return summaries

def main():
    global server
    ensure_paths()
    started = now()
    result = {"session": ROOT.name, "platform": "iluvatar", "candidate_mode": "v3",
              "candidate_source_sha256": EXPECTED_SOURCE_SHA, "started_utc": utc(),
              "hard_cutoff_epoch": CUTOFF, "stages": {}}
    env = env_for()
    status("server_starting")
    server_argv = [
        "vllm", "serve", str(MODEL), "--port", "9031",
        "--compilation-config", '{"cudagraph_mode":"FULL_DECODE_ONLY"}',
        "--served-model-name", "minicpm", "--gpu-memory-utilization", "0.85",
        "--max-model-len", "131072",
    ]
    server_log = ROOT / "candidate-server.log"
    log = server_log.open("w", encoding="utf-8")
    server = subprocess.Popen(server_argv, cwd="/workspace", env=env, stdin=subprocess.DEVNULL,
                              stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    try:
        ready_deadline = min(now() + 900, CUTOFF - 2 * 60 * 60 - ACCURACY_TIMEOUT - AUDIT_RESERVE - CLEANUP_RESERVE)
        while now() < ready_deadline:
            if server.poll() is not None:
                raise RuntimeError(f"vLLM exited during startup with code {server.returncode}")
            try:
                if not health_check():
                    raise RuntimeError("candidate server health endpoint returned non-200")
                models = request("/v1/models").get("data", [])
                if any(m.get("id") == "minicpm" for m in models):
                    break
            except Exception:
                pass
            status("server_starting")
            time.sleep(5)
        else:
            raise TimeoutError("fixed-argument candidate server did not become healthy in 15 minutes")
        pids = server_pids()
        result["server_argv"] = server_argv
        result["server_pid_tree_at_start"] = pids
        result["server_ready_utc"] = utc()
        status("server_ready", server_pid_tree=pids)

        smoke_cases = [[4096, 128, 8, 8], [16384, 128, 4, 4]]
        run_stage("throughput_smoke",
                  [sys.executable, str(BENCH), "--model", str(MODEL), "--served-model-name", "minicpm",
                   "--port", "9031", "--test-cases", json.dumps(smoke_cases, separators=(",", ":"))],
                  ROOT / "smoke", ROOT / "smoke.log", 900, env_for())
        smoke_csvs = list((ROOT / "smoke/benchmark_results").glob("raw_runs_*.csv"))
        if len(smoke_csvs) != 1:
            raise AssertionError(f"expected one smoke raw CSV, found {len(smoke_csvs)}")
        result["stages"]["throughput_smoke"] = {"csv": str(smoke_csvs[0]),
                                                  "cases": validate_csv(smoke_csvs[0], smoke_cases, smoke=True)}
        status("smoke_passed", smoke_csv=str(smoke_csvs[0]))

        if CUTOFF - now() < 2 * 60 * 60 + ACCURACY_TIMEOUT + AUDIT_RESERVE + CLEANUP_RESERVE:
            raise TimeoutError("after smoke, insufficient time remains for full benchmark, accuracy, and cleanup")
        full_cases = [[4096, 1024, 64, 256], [16384, 1024, 64, 128]]
        full_timeout = CUTOFF - now() - ACCURACY_TIMEOUT - AUDIT_RESERVE - CLEANUP_RESERVE
        run_stage("official_eight_round_benchmark",
                  [sys.executable, str(BENCH), "--model", str(MODEL), "--served-model-name", "minicpm",
                   "--port", "9031", "--test-cases", json.dumps(full_cases, separators=(",", ":"))],
                  ROOT / "official-benchmark", ROOT / "official-benchmark.log", full_timeout, env_for())
        full_csvs = list((ROOT / "official-benchmark/benchmark_results").glob("raw_runs_*.csv"))
        if len(full_csvs) != 1:
            raise AssertionError(f"expected one official raw CSV, found {len(full_csvs)}")
        perf_cases = validate_csv(full_csvs[0], full_cases)
        result["stages"]["official_eight_round_benchmark"] = {
            "csv": str(full_csvs[0]), "cases": perf_cases,
            "performance_pass": all(c["performance_pass"] for c in perf_cases),
        }
        status("performance_complete", performance_pass=result["stages"]["official_eight_round_benchmark"]["performance_pass"],
               benchmark_csv=str(full_csvs[0]))

        markers = []
        for path in ROOT.glob("attention-tiling-v3-runtime-*.json"):
            data = json.loads(path.read_text(encoding="utf-8"))
            if data.get("stage") == "optimized_kernel_launched" and data.get("mode") == "v3" and data.get("source_sha256") == EXPECTED_SOURCE_SHA:
                markers.append(data)
        live_pids = set(server_pids())
        marker = next((m for m in markers if int(m.get("pid", -1)) in live_pids), None)
        if marker is None:
            raise RuntimeError("candidate runtime marker did not match live server worker and source hash")
        result["stages"]["candidate_runtime_marker"] = marker
        status("candidate_launch_proven", marker=marker)

        accuracy_deadline = CUTOFF - CLEANUP_RESERVE
        accuracy_budget = min(ACCURACY_TIMEOUT, accuracy_deadline - now())
        if accuracy_budget <= 0:
            raise TimeoutError("no time remains for fresh accuracy run")
        eval_work = ROOT / "evalscope"
        env_acc = env_for(eval_work)
        run_stage("official_accuracy",
                  ["bash", str(ACCURACY_SCRIPT)],
                  ROOT, ROOT / "official-accuracy.log", accuracy_budget, env_acc)
        reports = list(eval_work.rglob("reports/minicpm/math_500.json"))
        if len(reports) != 1:
            raise AssertionError(f"expected exactly one fresh accuracy report, found {len(reports)}")
        accuracy_root = reports[0].parents[2]
        audit_path = ROOT / "accuracy-audit.json"
        run_stage("accuracy_artifact_audit",
                  [sys.executable, str(AUDITOR), "--run-dir", str(accuracy_root), "--out", str(audit_path)],
                  ROOT, ROOT / "accuracy-audit.log", 180, env_acc)
        accuracy = json.loads(audit_path.read_text(encoding="utf-8"))
        baseline = json.loads(BASELINE.read_text(encoding="utf-8"))
        base_score = baseline.get("accuracy", baseline.get("accuracy_audit", {}).get("score_recomputed"))
        accuracy.update({"baseline_accuracy": float(base_score),
                         "delta_percentage_points": (float(accuracy["score_recomputed"]) - float(base_score)) * 100.0})
        result["stages"]["accuracy"] = accuracy
        result["completed_utc"] = utc()
        result["elapsed_seconds"] = now() - started
        result["complete"] = bool(accuracy["integrity_pass"])
        result["overall_pass"] = bool(
            result["complete"] and result["stages"]["official_eight_round_benchmark"]["performance_pass"]
        )
        write_json(ROOT / "independent-result.json", result)
        status("complete", overall_pass=result["overall_pass"], result_path=str(ROOT / "independent-result.json"))
    except BaseException as exc:
        result["failure"] = {"type": type(exc).__name__, "message": str(exc), "at_utc": utc()}
        result["elapsed_seconds"] = now() - started
        write_json(ROOT / "partial-result.json", result)
        status("failed_or_interrupted", failure=result["failure"])
        raise
    finally:
        status("stopping_owned_server")
        stop_group(server, "candidate server")
        log.flush()
        log.close()
        status("stopped", server_process_exit=server.returncode if server else None)

if __name__ == "__main__":
    main()
