# SPDX-License-Identifier: Apache-2.0
"""Opt-in v3 shape-aware query tiling for the Iluvatar native kernel.

FLAGOS_TILED_ATTN_MODE must be exactly ``v3``.  Other values preserve the
original kernel launch.  This adapter changes only query-row launch geometry;
KV tile size, softmax math, masking, and the native backend remain unchanged.
"""
from dataclasses import dataclass
import hashlib
import json
import os
from pathlib import Path
import torch


@dataclass(frozen=True)
class LaunchConfig:
    block_m: int
    block_q: int
    num_warps: int
    bucket: str


def select_config(query_rows: int, num_seqs: int, mode: str = "v3") -> LaunchConfig | None:
    """Select query geometry from public batch shape only; None means native fallback."""
    if mode != "v3" or query_rows <= 0 or num_seqs <= 0 or query_rows <= num_seqs:
        return None
    # Query lengths are ragged, so this average is a scheduling proxy rather than
    # a claim that every request in the batch is a prefill.
    if query_rows >= num_seqs * 64:
        return LaunchConfig(64, 8, 4, "dense_prefill_like")
    if query_rows >= max(num_seqs * 8, 128):
        return LaunchConfig(32, 4, 4, "mixed_prefill")
    return None


def record_runtime(adapter, stage: str, **details) -> None:
    root = os.environ.get("FLAGOS_SESSION_ROOT")
    if not root:
        return
    destination = Path(root) / f"attention-tiling-v3-runtime-{os.getpid()}.json"
    payload = {
        "pid": os.getpid(),
        "stage": stage,
        "mode": adapter.mode,
        "source_file": __file__,
        "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "optimized_launches": adapter.optimized_launches,
        "fallback_launches": adapter.fallback_launches,
        **details,
    }
    temporary = destination.with_suffix(".tmp")
    temporary.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    temporary.replace(destination)


class QueryTiledKernel:
    def __init__(self, original):
        self.original = original
        self.mode = os.environ.get("FLAGOS_TILED_ATTN_MODE", "off").strip().lower()
        self.optimized_launches = 0
        self.fallback_launches = 0

    def __getattr__(self, name):
        return getattr(self.original, name)

    @staticmethod
    def _supported(query, kwargs) -> bool:
        return (
            query is not None
            and query.dtype == torch.bfloat16
            and kwargs.get("num_seqs", 0) > 0
            and not kwargs.get("IS_3D", True)
            and kwargs.get("HEAD_SIZE") == 128
            and kwargs.get("num_queries_per_kv") == 8
            and kwargs.get("TILE_SIZE") == 32
            and int(kwargs.get("KV_QUANT_MODE", -1)) == 0
            and kwargs.get("USE_CAUSAL", False)
            and kwargs.get("SLIDING_WINDOW") == 0
            and kwargs.get("CHUNK_LOOKBACK", -1) == -1
            and not any(
                kwargs.get(key, False)
                for key in (
                    "USE_TD",
                    "USE_MM_PREFIX",
                    "USE_SINKS",
                    "USE_ALIBI_SLOPES",
                    "USE_QQ_BIAS",
                    "USE_SOFTCAP",
                    "USE_PER_SEQ_CAUSAL",
                    "USE_FP8",
                )
            )
        )

    def __getitem__(self, grid):
        def launch(*args, **kwargs):
            query = kwargs.get("query_ptr")
            count = int(kwargs.get("num_seqs", 0))
            config = None
            if self.mode == "v3" and self._supported(query, kwargs):
                config = select_config(int(query.shape[0]), count, self.mode)

            if config is None:
                self.fallback_launches += 1
                return self.original[grid](*args, **kwargs)

            # Keep the v2 KV tile/reduction order and four-warps configuration.
            # The smaller mixed tile is isolated behind v3 until it is measured.
            kwargs = dict(
                kwargs,
                BLOCK_M=config.block_m,
                BLOCK_Q=config.block_q,
                num_warps=config.num_warps,
            )
            selected_grid = (
                query.shape[0] // config.block_q + count,
                kwargs["num_query_heads"] // kwargs["num_queries_per_kv"],
            )
            self.optimized_launches += 1
            if self.optimized_launches == 1:
                record_runtime(
                    self,
                    "optimized_kernel_launched",
                    query_shape=list(query.shape),
                    num_seqs=count,
                    bucket=config.bucket,
                    block_m=config.block_m,
                    block_q=config.block_q,
                    kv_tile=kwargs["TILE_SIZE"],
                )
            return self.original[selected_grid](*args, **kwargs)

        return launch


def install() -> bool:
    """Wrap the native kernel only on Iluvatar and only when v3 is requested."""
    from vllm.platforms import current_platform
    if getattr(current_platform, "vendor_name", None) != "iluvatar":
        return False
    if os.environ.get("FLAGOS_TILED_ATTN_MODE", "off").strip().lower() != "v3":
        return False

    import vllm.v1.attention.ops.triton_unified_attention as native
    if isinstance(native.kernel_unified_attention, QueryTiledKernel):
        return native.kernel_unified_attention.mode == "v3"
    adapter = QueryTiledKernel(native.kernel_unified_attention)
    native.kernel_unified_attention = adapter
    record_runtime(adapter, "installed")
    return True
