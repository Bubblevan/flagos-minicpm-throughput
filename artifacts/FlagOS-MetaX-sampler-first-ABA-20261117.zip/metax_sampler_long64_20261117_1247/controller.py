"""Warm long-context64-concurrency A/B/A; same frozen validated sampler source."""
import asyncio,datetime as dt,hashlib,json,os,shutil,signal,socket,subprocess,sys,time,traceback
from pathlib import Path
import requests
BASE=Path(__file__).resolve().parent;sys.path.insert(0,str(BASE/'tools'))
from metax_prefix_trial import workload,stop_owned
ROOT=Path('/data/tokenforge-artifacts/metax_sampler_long64_20261117_1247')
OLD=Path('/data/tokenforge-artifacts/metax_sampler_guarded_short_20261117_1230')
SOURCE=Path('/data/tokenforge-sources/metax_sampler_guarded_20261117_1230/candidate')
END=dt.datetime.fromisoformat('2026-11-17T13:14:00+08:00').timestamp()
server=None
def write(name,value):
    p=ROOT/name;p.parent.mkdir(parents=True,exist_ok=True);t=p.with_suffix('.tmp');t.write_text(json.dumps(value,indent=2));t.replace(p)
def state(s,**kw):
    row=dict(stage=s,at=time.time(),deadline=END,**kw);write('status.json',row);print(json.dumps(row),flush=True)
def reset():requests.post('http://127.0.0.1:9031/reset_prefix_cache',timeout=20).raise_for_status()
def main():
    global server
    assert END-time.time()>15*60
    assert not ROOT.exists()
    assert not json.loads((OLD/'cleanup.json').read_text())['owned_survivors']
    with socket.socket() as s:assert s.connect_ex(('127.0.0.1',9031))!=0
    assert 'no process found' in subprocess.check_output(['mx-smi'],text=True).lower()
    manifest=json.loads((OLD/'source-manifest.json').read_text())
    for f,h in manifest['files'].items():assert hashlib.sha256((SOURCE/f).read_bytes()).hexdigest()==h
    ROOT.mkdir(parents=True);CONTROL=ROOT/'diagnostic-mode.txt';CONTROL.write_text('native')
    for n in ['source-manifest.json','shadow-proof.json','short-summary.json']:shutil.copy2(OLD/n,ROOT/('previous-'+n))
    shutil.copy2(__file__,ROOT/'controller.py')
    cache=Path('/data/tokenforge-caches')/ROOT.name
    for n in ['triton','vllm','inductor']:
        p=Path('/data/tokenforge-caches')/OLD.name/n
        if p.exists():shutil.copytree(p,cache/n)
    env=dict(os.environ,VLLM_PLUGINS='fl',PYTHONPATH=str(SOURCE),TORCHINDUCTOR_COMPILE_THREADS='1',FLAGOS_SESSION_ROOT=str(ROOT),PYTHONDONTWRITEBYTECODE='1',
        VLLM_SERVER_DEV_MODE='1',FLAGOS_METAX_TOPP_DIAGNOSTIC_CONTROL=str(CONTROL),VLLM_CACHE_ROOT=str(cache/'vllm'),TRITON_CACHE_DIR=str(cache/'triton'),TORCHINDUCTOR_CACHE_DIR=str(cache/'inductor'))
    argv=['vllm','serve','/workspace/MiniCPM5-2B','--port','9031','--served-model-name','minicpm','--gpu-memory-utilization','0.85','--max-model-len','131072']
    write('plan.json',dict(official_score=False,source_manifest=manifest,argv=argv,cache_origin=str(OLD),
        rationale='Earlier16-request diagnostic uses native sampler but drifts67percent: reject causal interpretation. Test actual64concurrency with shape-matched long-context prewarm.',
        warmup=[64,16384,256],measured=[64,16384,1024],order=['native_a1','candidate_b','native_a2'],gates=dict(min_gain=.02,max_drift=.05,max_ttft_ratio=1.05),numerical_shadow_reused_same_source=True))
    with (ROOT/'server.log').open('w') as f:server=subprocess.Popen(argv,env=env,stdout=f,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,start_new_session=True,cwd='/workspace')
    state('server_starting',server_pid=server.pid)
    limit=min(time.time()+600,END-900)
    while time.time()<limit:
        if server.poll() is not None:raise RuntimeError('Service exited')
        try:
            if requests.get('http://127.0.0.1:9031/health',timeout=2).status_code==200:break
        except requests.RequestException:pass
        time.sleep(3)
    else:raise TimeoutError('No ready service')
    state('long_shape_warmup');reset();write('warmup.json',asyncio.run(asyncio.wait_for(workload(7100,64,16384,256),timeout=300)))
    rows={}
    for label,mode in [('native_a1','native'),('candidate_b','candidate'),('native_a2','native')]:
        CONTROL.write_text(mode);reset();state(label)
        rows[label]=asyncio.run(asyncio.wait_for(workload(7101,64,16384,1024),timeout=min(360,END-time.time()-30)))
        write(label+'.json',rows[label])
    a,b,c=[rows[n] for n in ['native_a1','candidate_b','native_a2']]
    assert [r['prompt_sha256'] for r in a['rows']]==[r['prompt_sha256'] for r in b['rows']]==[r['prompt_sha256'] for r in c['rows']]
    gain=b['total_tokens_per_second']/((a['total_tokens_per_second']+c['total_tokens_per_second'])/2)-1
    drift=c['total_tokens_per_second']/a['total_tokens_per_second']-1
    ttft=b['mean_ttft_s']/((a['mean_ttft_s']+c['mean_ttft_s'])/2)
    write('long64-summary.json',dict(complete=True,official_score=False,gain=gain,native_drift=drift,ttft_ratio=ttft,
        long64_go=gain>=.02 and abs(drift)<=.05 and ttft<=1.05,source_manifest=manifest,previous_4k_observed_gain=.08902778256860278))
    state('long64_complete')
if __name__=='__main__':
    def interrupted(*_):raise TimeoutError('Authorized bounded diagnostic cutoff')
    signal.signal(signal.SIGALRM,interrupted);signal.signal(signal.SIGTERM,interrupted);signal.alarm(max(1,int(END-time.time())))
    failure=None
    try:main()
    except BaseException as e:
        failure=dict(error=repr(e),traceback=traceback.format_exc());print(traceback.format_exc(),flush=True)
        if ROOT.exists():write('failure.json',failure)
    finally:
        signal.alarm(0);clean=stop_owned(server) if server else {}
        if ROOT.exists():write('cleanup.json',clean);state('stopped',failure=failure,cleanup=clean)
