"""Frozen source, same-server native/candidate/native; original sampling policy."""
import asyncio,datetime as dt,hashlib,json,os,shutil,signal,socket,subprocess,sys,time,traceback
from pathlib import Path
import requests
BASE=Path(__file__).resolve().parent;sys.path.insert(0,str(BASE/'tools'))
from metax_prefix_trial import workload,stop_owned
ROOT=Path('/data/tokenforge-artifacts/metax_sampler_guarded_short_20261117_1230')
END=dt.datetime.fromisoformat('2026-11-17T12:57:00+08:00').timestamp()
SOURCE=Path('/data/tokenforge-sources/metax_sampler_guarded_20261117_1230/candidate')
CONTROL=ROOT/'diagnostic-mode.txt'
server=None
def write(name,value):
    p=ROOT/name;p.parent.mkdir(parents=True,exist_ok=True);t=p.with_suffix('.tmp');t.write_text(json.dumps(value,indent=2));t.replace(p)
def state(stage,**kw):
    row=dict(stage=stage,at=time.time(),deadline=END,**kw);write('status.json',row);print(json.dumps(row),flush=True)
def reset_cache():
    r=requests.post('http://127.0.0.1:9031/reset_prefix_cache',timeout=20);r.raise_for_status()
def main():
    global server
    assert END-time.time()>900
    with socket.socket() as s:assert s.connect_ex(('127.0.0.1',9031))!=0
    assert 'no process found' in subprocess.check_output(['mx-smi'],text=True).lower()
    proof=json.loads(Path('/data/tokenforge-artifacts/metax_sampler_final_micro_20261117_1230/probe.json').read_text());assert proof['complete'] and len(proof['cases'])==30
    ROOT.mkdir(parents=True,exist_ok=False);SOURCE.parent.mkdir(parents=True,exist_ok=False)
    shutil.copytree('/data/tokenforge-sources/metax_20261117_0118/candidate',SOURCE,ignore=shutil.ignore_patterns('.git','__pycache__'))
    patches=SOURCE/'vllm_fl/dispatch/backends/vendor/metax/patches'
    shutil.copy2(BASE/'topk_topp_sampler_candidate.py',patches/'topk_topp_sampler.py')
    shutil.copy2(BASE/'top_p_shortlist.py',patches/'top_p_shortlist.py')
    shutil.copy2(BASE/'shortlist_kernels.py',patches/'shortlist_kernels.py')
    manifest={str(p.relative_to(SOURCE)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [patches/'topk_topp_sampler.py',patches/'top_p_shortlist.py',patches/'shortlist_kernels.py',SOURCE/'vllm_fl/dispatch/backends/vendor/metax/impl/attention/flash_attn.py']}
    write('source-manifest.json',dict(base_commit='13eb9be69ecc5b5ca4f79c44e9ee40081eaa1bf0',source=str(SOURCE),files=manifest))
    shutil.copy2(__file__,ROOT/'controller.py');shutil.copy2(BASE/'top_p_shortlist.py',ROOT/'top_p_shortlist.py');shutil.copy2(BASE/'topk_topp_sampler_candidate.py',ROOT/'topk_topp_sampler.py')
    cache=Path('/data/tokenforge-caches')/ROOT.name
    shutil.copytree('/data/tokenforge-caches/metax_sampler_final_micro_20261117_1230/triton',cache/'triton')
    write('cache-origin.json',dict(origin='same-device correctness micro',triton_source='/data/tokenforge-caches/metax_sampler_final_micro_20261117_1230/triton',shared_across_all_ABA_conditions=True,performance_gain_claimed=False))
    env=dict(os.environ,VLLM_PLUGINS='fl',PYTHONPATH=str(SOURCE),TORCHINDUCTOR_COMPILE_THREADS='1',FLAGOS_SESSION_ROOT=str(ROOT),PYTHONDONTWRITEBYTECODE='1',
        VLLM_SERVER_DEV_MODE='1',FLAGOS_METAX_TOPP_DIAGNOSTIC_CONTROL=str(CONTROL),VLLM_CACHE_ROOT=str(cache/'vllm'),TRITON_CACHE_DIR=str(cache/'triton'),TORCHINDUCTOR_CACHE_DIR=str(cache/'inductor'))
    CONTROL.write_text('native')
    argv=['vllm','serve','/workspace/MiniCPM5-2B','--port','9031','--served-model-name','minicpm','--gpu-memory-utilization','0.85','--max-model-len','131072']
    write('plan.json',dict(official_score=False,argv=argv,order=['shadow','native_a1','candidate_b','native_a2'],same_loaded_model_and_source=True,prefix_cache_reset_before_each_workload=True,
        hypothesis='Preserve original nucleus policy and RNG; sort only mass-certified bounded shortlist, fall back on uncertain boundaries/ties or unsupported top-k.',
        gate={'4k_gain':.12,'16k_small_batch_gain_floor':-.03,'max_native_drift':.08,'max_ttft_ratio':1.05,'min_shadow_equal_calls':32},limitations='One matched seed per shape;16Kshort has16requests and intentionally uses unchanged small-batch sampling;full64concurrency acceptance still required. Original sampling stochastic; developer routes enabled only to reset cache, not official score.'))
    with (ROOT/'server.log').open('w') as f:server=subprocess.Popen(argv,env=env,stdout=f,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,start_new_session=True,cwd='/workspace')
    state('server_starting',server_pid=server.pid)
    ready_by=min(time.time()+600,END-300)
    while time.time()<ready_by:
        if server.poll() is not None:raise RuntimeError('Service exited')
        try:
            if requests.get('http://127.0.0.1:9031/health',timeout=2).status_code==200:break
        except requests.RequestException:pass
        time.sleep(3)
    else:raise TimeoutError('No readiness')
    CONTROL.write_text('shadow');state('shadow_filter_differential');reset_cache()
    write('shadow-workload.json',asyncio.run(asyncio.wait_for(workload(6900,64,512,1024),timeout=360)))
    markers=[p for p in ROOT.glob('sampler-runtime-*.json') if json.loads(p.read_text()).get('shadow_equal_calls',0)>0];assert len(markers)==1
    marker=json.loads(markers[0].read_text());write('shadow-proof.json',marker)
    assert marker['shadow_equal_calls']>=32 and marker['stats']['shortlist_rows']>0,'No proven real-model fast-path coverage'
    results={}
    for label,mode in [('native_a1','native'),('candidate_b','candidate'),('native_a2','native')]:
        CONTROL.write_text(mode);state(label+'_warmup');reset_cache()
        asyncio.run(asyncio.wait_for(workload(6910,64,128,32),timeout=180))
        results[label]={}
        for shape,n,length,output,seed in [('4k',64,4096,1024,6911),('16k',16,16384,1024,6912)]:
            reset_cache();state(label+'_'+shape)
            r=asyncio.run(asyncio.wait_for(workload(seed,n,length,output,concurrency=64),timeout=min(300,END-time.time()-30)))
            write(label+'-'+shape+'.json',r);results[label][shape]=r
    summary={}
    for shape in ['4k','16k']:
        a=results['native_a1'][shape];b=results['candidate_b'][shape];a2=results['native_a2'][shape]
        assert [x['prompt_sha256'] for x in a['rows']]==[x['prompt_sha256'] for x in b['rows']]==[x['prompt_sha256'] for x in a2['rows']]
        summary[shape]=dict(gain=b['total_tokens_per_second']/((a['total_tokens_per_second']+a2['total_tokens_per_second'])/2)-1,
            native_drift=a2['total_tokens_per_second']/a['total_tokens_per_second']-1,
            ttft_ratio=b['mean_ttft_s']/((a['mean_ttft_s']+a2['mean_ttft_s'])/2))
    go=summary['4k']['gain']>=.12 and summary['16k']['gain']>=-.03 and all(abs(s['native_drift'])<=.08 and s['ttft_ratio']<=1.05 for s in summary.values())
    write('short-summary.json',dict(complete=True,official_score=False,short_go=go,cases=summary,source_manifest=manifest));state('short_complete',short_go=go)
if __name__=='__main__':
    def interrupted(*_):raise TimeoutError('Short trial cutoff')
    signal.signal(signal.SIGALRM,interrupted);signal.signal(signal.SIGTERM,interrupted);signal.alarm(max(1,int(END-time.time())))
    failure=None
    try:main()
    except BaseException as e:
        failure=dict(error=repr(e),traceback=traceback.format_exc());print(traceback.format_exc(),flush=True)
        if ROOT.exists():write('failure.json',failure)
    finally:
        signal.alarm(0);clean=stop_owned(server) if server else {}
        if ROOT.exists():write('cleanup.json',clean);state('stopped',failure=failure,cleanup=clean)
