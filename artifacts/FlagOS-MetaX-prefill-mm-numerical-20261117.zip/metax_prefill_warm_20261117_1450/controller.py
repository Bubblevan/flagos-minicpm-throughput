"""Continuous-arrival original-generator diagnostic for the fused sampler."""
import asyncio,datetime as dt,hashlib,importlib.util,json,os,shutil,signal,socket,subprocess,sys,time,traceback
from pathlib import Path
import requests
BASE=Path(__file__).resolve().parent;sys.path.insert(0,str(BASE/'tools'))
from metax_prefix_trial import workload,stop_owned
ROOT=Path('/data/tokenforge-artifacts/metax_prefill_warm_20261117_1450')
SOURCE=Path('/data/tokenforge-sources/TokenForge-fused-candidate-20261117/vllm-plugin-FL')
END=dt.datetime.fromisoformat('2026-11-17T15:12:00+08:00').timestamp()
server=None
def write(n,j):
    p=ROOT/n;p.parent.mkdir(parents=True,exist_ok=True);t=p.with_suffix('.tmp');t.write_text(json.dumps(j,indent=2));t.replace(p)
def state(s,**kw):write('status.json',dict(stage=s,at=time.time(),deadline=END,**kw));print(s,flush=True)
def reset():requests.post('http://127.0.0.1:9031/reset_prefix_cache',timeout=20).raise_for_status()
def main():
    global server
    assert END-time.time()>12*60
    assert not ROOT.exists()
    assert 'no process found' in subprocess.check_output(['mx-smi'],text=True).lower()
    proof=json.loads(Path('/data/tokenforge-artifacts/metax_sampler_fused_micro_20261117_1425/probe.json').read_text());assert proof['complete'] and len(proof['cases'])==35
    ROOT.mkdir(parents=True);control=ROOT/'diagnostic-mode.txt';control.write_text('native')
    patches=SOURCE/'vllm_fl/dispatch/backends/vendor/metax/patches'
    paths=[patches/n for n in ['topk_topp_sampler.py','top_p_shortlist.py','shortlist_kernels.py','sampler_budget.py']]+[SOURCE/'vllm_fl/dispatch/backends/vendor/metax/impl/attention/flash_attn.py']
    manifest=dict(base_commit='13eb9be69ecc5b5ca4f79c44e9ee40081eaa1bf0',source=str(SOURCE),files={p.relative_to(SOURCE).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in paths})
    write('source-manifest.json',manifest);shutil.copy2(__file__,ROOT/'controller.py')
    cache=Path('/data/tokenforge-caches')/ROOT.name
    for n in ['triton','vllm','inductor']:
        old=Path('/data/tokenforge-caches/metax_sampler_fused_short_20261117_1425')/n
        if old.exists():shutil.copytree(old,cache/n)
    env=dict(os.environ,VLLM_PLUGINS='fl',PYTHONPATH=str(SOURCE),TORCHINDUCTOR_COMPILE_THREADS='1',FLAGOS_SESSION_ROOT=str(ROOT),PYTHONDONTWRITEBYTECODE='1',VLLM_SERVER_DEV_MODE='1',FLAGOS_METAX_TOPP_DIAGNOSTIC_CONTROL=str(control),VLLM_CACHE_ROOT=str(cache/'vllm'),TRITON_CACHE_DIR=str(cache/'triton'),TORCHINDUCTOR_CACHE_DIR=str(cache/'inductor'))
    argv=['vllm','serve','/workspace/MiniCPM5-2B','--port','9031','--served-model-name','minicpm','--gpu-memory-utilization','0.85','--max-model-len','131072']
    profiler=dict(profiler='torch',torch_profiler_dir=str(ROOT/'profiles'),torch_profiler_with_stack=False,torch_profiler_record_shapes=True,ignore_frontend=True,max_iterations=8)
    argv+=['--profiler-config',json.dumps(profiler)]
    write('plan.json',dict(official_score=False,profiler_enabled_only_for_separate_prefill_stage=True,prior_source_numerical_proof=35,prior_diagnostic_rejected_due_native_drift=.1492389253,full_shape_warmup=[4096,1024,64,128],argv=argv,measured=[4096,1024,64,128],generator='Original installed vllm bench serve random generator, default seed and sampling unchanged; HTTP CPU client only',hypothesis='Fuse threshold choice and shortlisted CDF/mask/tie/safety to remove many intermediate tensor launches; prior context guard and native long path unchanged',gates=dict(min_gain=.10,min_candidate_tps=5150,max_ttft_ratio=1.0,max_native_drift=.05,min_shadow=32),cache_origin='Previous failed four-round4K session and fused numerical micro; operational warm cache, not score credit',accuracy_not_reused=True))
    with (ROOT/'server.log').open('w') as f:server=subprocess.Popen(argv,env=env,stdout=f,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,start_new_session=True,cwd='/workspace')
    state('server_starting',server_pid=server.pid)
    limit=min(time.time()+480,END-10*60)
    while time.time()<limit:
        if server.poll() is not None:raise RuntimeError('Service exited')
        try:
            if requests.get('http://127.0.0.1:9031/health',timeout=2).status_code==200:break
        except requests.RequestException:pass
        time.sleep(2)
    else:raise TimeoutError('No readiness within diagnostic budget')
    control.write_text('shadow');reset();state('shadow')
    write('shadow-workload.json',asyncio.run(asyncio.wait_for(workload(7500,64,512,64),timeout=90)))
    markers=[json.loads(p.read_text()) for p in ROOT.glob('sampler-runtime-*.json')]
    marker=next(x for x in markers if x['shadow_equal_calls']>=32);assert marker['stats']['shortlist_rows']>0;write('shadow-proof.json',marker)
    bench=Path('/workspace/vllm-plugin-FL/benchmarks/benchmark_throughput_serve.py');spec=importlib.util.spec_from_file_location('original_bench',bench);original=importlib.util.module_from_spec(spec);spec.loader.exec_module(original)
    client_env=dict(env,VLLM_PLUGINS='',CUDA_VISIBLE_DEVICES='',MACA_VISIBLE_DEVICES='')
    def run_cli(label,n,out):
        reset();state(label)
        cmd=['vllm','bench','serve','--backend','vllm','--model','minicpm','--tokenizer','/workspace/MiniCPM5-2B','--endpoint','/v1/completions','--host','localhost','--port','9031','--dataset-name','random','--ignore-eos','--random-input-len','4096','--random-output-len',str(out),'--max-concurrency','64','--num-prompts',str(n)]
        with (ROOT/(label+'.log')).open('w') as f:p=subprocess.Popen(cmd,env=client_env,stdout=f,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,start_new_session=True)
        try:code=p.wait(timeout=min(260,END-time.time()-35))
        except BaseException:stop_owned(p);raise
        assert code==0
        data=original.extract_metrics((ROOT/(label+'.log')).read_text());assert data['successful_requests']==n and data['total_input_tokens']==4096*n and data['total_output_tokens']==out*n
        write(label+'.json',data);return data
    control.write_text('native');reset();state('prefill_profile')
    requests.post('http://127.0.0.1:9031/start_profile',timeout=30).raise_for_status()
    try:write('prefill-profile-workload.json',asyncio.run(asyncio.wait_for(workload(7600,64,4096,32),timeout=100)))
    finally:requests.post('http://127.0.0.1:9031/stop_profile',timeout=60).raise_for_status()
    run_cli('full_shape_warmup',128,1024)
    rows={}
    for label,mode in [('native_a1','native'),('candidate_b','candidate'),('native_a2','native')]:
        control.write_text(mode);rows[label]=run_cli(label,128,1024)
    a,b,c=[rows[k] for k in ['native_a1','candidate_b','native_a2']]
    gain=b['total_token_throughput']/((a['total_token_throughput']+c['total_token_throughput'])/2)-1
    drift=c['total_token_throughput']/a['total_token_throughput']-1
    ttft=b['mean_ttft_ms']/((a['mean_ttft_ms']+c['mean_ttft_ms'])/2)
    write('prior-long-branch-reference.json',json.loads(Path('/data/tokenforge-artifacts/metax_sampler_fused_short_20261117_1425/long-runtime-proof.json').read_text()))
    go=gain>=.10 and b['total_token_throughput']>=5150 and abs(drift)<=.05 and ttft<=1.0
    write('short-summary.json',dict(complete=True,official_score=False,short_go=go,gain=gain,native_drift=drift,ttft_ratio=ttft,candidate_tps=b['total_token_throughput'],measured_requests=128,generator='original vllm bench serve random',source_manifest=manifest))
    state('short_complete')
if __name__=='__main__':
    def interrupted(*_):raise TimeoutError('Bounded fused diagnostic cutoff')
    signal.signal(signal.SIGALRM,interrupted);signal.signal(signal.SIGTERM,interrupted);signal.alarm(max(1,int(END-time.time())))
    failure=None
    try:main()
    except BaseException as e:
        failure=dict(error=repr(e),traceback=traceback.format_exc());print(traceback.format_exc(),flush=True)
        if ROOT.exists():write('failure.json',failure)
    finally:
        signal.alarm(0);clean=stop_owned(server) if server else {}
        if ROOT.exists():write('cleanup.json',clean);state('stopped',failure=failure,cleanup=clean)
