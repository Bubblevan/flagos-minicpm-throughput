"""Bounded diagnostics; generated timings are NOT competition scores.

No model, dataset or installed source is modified. The server has an extra
profiler option only for this diagnostic run and is stopped on completion.
"""
import asyncio
import datetime as dt
import json
import os
from pathlib import Path
import random
import signal
import subprocess
import threading
import time

import aiohttp
import psutil
import requests

ROOT = Path('/workspace/tokenforge-artifacts/repro_20261029_1218')
URL = 'http://127.0.0.1:9031'
DEADLINE = dt.datetime(2026, 10, 29, 17, 55, tzinfo=dt.timezone(dt.timedelta(hours=8))).timestamp()


def state(stage, **kwargs):
    value = dict(stage=stage, at=dt.datetime.now(dt.timezone.utc).isoformat(), **kwargs)
    p = ROOT/'status.tmp'
    p.write_text(json.dumps(value, indent=2))
    p.replace(ROOT/'status.json')
    print(json.dumps(value), flush=True)


def textfile(path):
    try:
        return Path(path).read_text().strip()
    except OSError:
        return None


def telemetry(pid, stop):
    with (ROOT/'telemetry.jsonl').open('a') as f:
        while not stop.is_set():
            row = dict(at=time.time(), cpu_stat=textfile('/sys/fs/cgroup/cpu/cpu.stat'),
                       memory_usage=textfile('/sys/fs/cgroup/memory/memory.usage_in_bytes'),
                       host_load=os.getloadavg(), processes=[])
            try:
                parent = psutil.Process(pid)
                for p in [parent] + parent.children(recursive=True):
                    try:
                        c = p.cpu_times()
                        row['processes'].append(dict(pid=p.pid, name=p.name(), threads=p.num_threads(),
                            rss=p.memory_info().rss, cpu_user=c.user, cpu_system=c.system,
                            affinity=p.cpu_affinity()))
                    except psutil.Error:
                        pass
                row['gpu'] = subprocess.check_output(['ixsmi','-q','-d','CLOCK,PERFORMANCE,POWER,UTILIZATION'], text=True, timeout=5)
            except Exception as e:
                row['telemetry_error'] = repr(e)
            f.write(json.dumps(row)+'\n'); f.flush()
            stop.wait(5)


async def workload(n, length, output, seed, profile_mode=None):
    rng = random.Random(seed)
    prompts = [[rng.randrange(1000,100000) for _ in range(length)] for _ in range(n)]
    first = set()
    all_first = asyncio.Event()
    timeout = aiohttp.ClientTimeout(total=600)
    rows = []
    started = time.monotonic()
    async with aiohttp.ClientSession(timeout=timeout) as client:
        async def profile(path):
            async with client.post(URL+path) as r:
                body = await r.text()
                if r.status != 200:
                    raise RuntimeError(f'{path}: {r.status}: {body[:500]}')
        async def one(i, prompt):
            t = time.monotonic(); ttft = None; usage = None; reason = None
            body = dict(model='minicpm', prompt=prompt, max_tokens=output, ignore_eos=True,
                        stream=True, stream_options={'include_usage':True})
            async with client.post(URL+'/v1/completions', json=body) as r:
                if r.status != 200:
                    raise RuntimeError(f'Request failed {r.status}: {(await r.text())[:500]}')
                async for line in r.content:
                    if not line.startswith(b'data: '):
                        continue
                    raw = line[6:].strip()
                    if raw == b'[DONE]':
                        continue
                    chunk = json.loads(raw)
                    if chunk.get('usage'):
                        usage = chunk['usage']
                    for choice in chunk.get('choices',[]):
                        if choice.get('text') and ttft is None:
                            ttft = time.monotonic()-t; first.add(i)
                            if len(first)==n:
                                all_first.set()
                        reason = choice.get('finish_reason') or reason
            if ttft is None:
                raise RuntimeError('No generated content')
            rows.append(dict(id=i,ttft_seconds=ttft,duration_seconds=time.monotonic()-t,
                             usage=usage,finish_reason=reason))
        async def capture_decode():
            await asyncio.wait_for(all_first.wait(), timeout=300)
            await profile('/start_profile')
            state('profiling_decode', requests=n, input_len=length, output_len=output)
        if profile_mode=='prefill':
            await profile('/start_profile')
        tasks = [asyncio.create_task(one(i,p)) for i,p in enumerate(prompts)]
        if profile_mode=='decode':
            tasks.append(asyncio.create_task(capture_decode()))
        try:
            await asyncio.gather(*tasks)
        finally:
            if profile_mode:
                await profile('/stop_profile')
    return dict(requests=n,input_len=length,output_len=output,seed=seed,
                profile_mode=profile_mode,elapsed_seconds=time.monotonic()-started,
                rows=sorted(rows,key=lambda x:x['id']),official_score=False)


def main():
    if time.time() > DEADLINE-1200:
        raise RuntimeError('Insufficient reserved time for diagnostic run')
    try:
        requests.get(URL+'/health',timeout=2)
    except requests.RequestException:
        pass
    else:
        raise RuntimeError('A server already answers on 9031; inspect before starting another')
    profile_config = dict(profiler='torch',torch_profiler_dir=str(ROOT/'profiles'),
                          torch_profiler_with_stack=False,torch_profiler_record_shapes=False,
                          ignore_frontend=True,max_iterations=8)
    cmd = ['vllm','serve','/workspace/MiniCPM5-2B','--port','9031',
           '--compilation-config','{"cudagraph_mode":"FULL_DECODE_ONLY"}',
           '--served-model-name','minicpm','--gpu-memory-utilization','0.85',
           '--max-model-len','131072','--profiler-config',json.dumps(profile_config)]
    env = dict(os.environ,VLLM_PLUGINS='fl')
    (ROOT/'diagnostic-server-command.json').write_text(json.dumps(dict(argv=cmd,profiler_only=True),indent=2))
    with (ROOT/'diagnostic-server.log').open('w') as f:
        server = subprocess.Popen(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,
                                  stdin=subprocess.DEVNULL,start_new_session=True)
    (ROOT/'diagnostic-server.pid').write_text(str(server.pid))
    stop = threading.Event()
    monitor = threading.Thread(target=telemetry,args=(server.pid,stop),daemon=True)
    monitor.start()
    try:
        state('diagnostic_server_starting',server_pid=server.pid)
        ready_by = time.time()+900
        while time.time()<ready_by:
            if server.poll() is not None:
                raise RuntimeError(f'Diagnostic server exited {server.returncode}')
            try:
                if requests.get(URL+'/health',timeout=3).status_code==200:
                    break
            except requests.RequestException:
                pass
            time.sleep(5)
        else:
            raise RuntimeError('Server readiness timed out')
        results = []
        for name,args in [('warmup',(8,4096,64,1029,None)),
                          ('prefill',(4,16384,16,1030,'prefill')),
                          ('decode',(8,4096,256,1031,'decode'))]:
            state('diagnostic_'+name)
            result = asyncio.run(workload(*args))
            (ROOT/(name+'-diagnostic.json')).write_text(json.dumps(result,indent=2))
            results.append(dict(name=name,elapsed_seconds=result['elapsed_seconds']))
        state('diagnostics_complete_waiting_analysis',results=results,official_score=False)
    finally:
        if server.poll() is None:
            os.killpg(server.pid,signal.SIGTERM)
            try:
                server.wait(timeout=20)
            except subprocess.TimeoutExpired:
                os.killpg(server.pid,signal.SIGKILL); server.wait()
        stop.set(); monitor.join(timeout=8)


if __name__=='__main__':
    try:
        main()
    except Exception as e:
        state('diagnostics_failed',error=repr(e),official_score=False)
        raise
