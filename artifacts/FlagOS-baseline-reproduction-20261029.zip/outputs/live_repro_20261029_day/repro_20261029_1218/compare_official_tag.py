"""Check the exact required FlagGems tag with independent build caches.

This aligns the documented baseline, not an entrant-authored optimization.
Only short diagnostic workloads run here; official scoring needs the full script.
"""
import asyncio
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import threading
import time

import requests
from diagnose import ROOT, URL, DEADLINE, state, telemetry, workload


def main():
    validation = json.loads((ROOT/'frozen-source-validation.json').read_text())
    source = Path(validation['source_root'])
    tree = subprocess.check_output(['git','-C',str(source),'write-tree'],text=True).strip()
    assert tree == validation['expected_git_tree']
    try:
        requests.get(URL+'/health',timeout=2)
    except requests.RequestException:
        pass
    else:
        raise RuntimeError('Another server is active; inspect before starting')
    if time.time()>DEADLINE-1800:
        raise RuntimeError('Insufficient reserved time')
    cache=Path('/workspace/tokenforge-caches/repro_20261029_official_tag')
    env=dict(os.environ,VLLM_PLUGINS='fl',PYTHONPATH=str(source/'src'),
             VLLM_CACHE_ROOT=str(cache/'vllm'),TRITON_CACHE_DIR=str(cache/'triton'),
             TORCHINDUCTOR_CACHE_DIR=str(cache/'inductor'))
    probe="import flag_gems,json; print(json.dumps({'file':flag_gems.__file__}))"
    p=subprocess.run([sys.executable,'-c',probe],env=env,stdout=subprocess.PIPE,
                     stderr=subprocess.STDOUT,text=True,timeout=120)
    (ROOT/'aligned-import-check.log').write_text(p.stdout)
    assert p.returncode==0 and str(source/'src/flag_gems') in p.stdout,p.stdout[-2000:]
    cmd=['vllm','serve','/workspace/MiniCPM5-2B','--port','9031',
         '--compilation-config','{"cudagraph_mode":"FULL_DECODE_ONLY"}',
         '--served-model-name','minicpm','--gpu-memory-utilization','0.85',
         '--max-model-len','131072']
    (ROOT/'aligned-runtime-environment.json').write_text(json.dumps(dict(
        source_root=str(source),target_commit=validation['target_commit'],
        target_tree=tree,environment={k:env[k] for k in ['VLLM_PLUGINS','PYTHONPATH',
            'VLLM_CACHE_ROOT','TRITON_CACHE_DIR','TORCHINDUCTOR_CACHE_DIR']},
        argv=cmd,original_install_untouched=True),indent=2))
    with (ROOT/'aligned-server.log').open('w') as f:
        server=subprocess.Popen(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,
                                stdin=subprocess.DEVNULL,start_new_session=True)
    (ROOT/'aligned-server.pid').write_text(str(server.pid))
    stop=threading.Event()
    monitor=threading.Thread(target=telemetry,args=(server.pid,stop),daemon=True)
    monitor.start()
    try:
        state('aligned_tag_trial_starting',server_pid=server.pid,target_tree=tree)
        ready_by=time.time()+1200
        while time.time()<ready_by:
            if server.poll() is not None:
                raise RuntimeError(f'Aligned server exited {server.returncode}')
            try:
                if requests.get(URL+'/health',timeout=3).status_code==200:
                    break
            except requests.RequestException:
                pass
            time.sleep(5)
        else:
            raise RuntimeError('Aligned server readiness timed out')
        state('aligned_tag_trial_warmup')
        result=asyncio.run(workload(64,4096,64,3000))
        (ROOT/'aligned-warmup.json').write_text(json.dumps(result,indent=2))
        results=[]
        for name,seed in [('aligned_a',3001),('aligned_b',3002)]:
            state('trial_'+name)
            result=asyncio.run(workload(64,4096,256,seed))
            result['total_tokens_per_second']=64*(4096+256)/result['elapsed_seconds']
            result['mean_ttft_seconds']=sum(x['ttft_seconds'] for x in result['rows'])/64
            (ROOT/(name+'.json')).write_text(json.dumps(result,indent=2))
            results.append(dict(name=name,elapsed_seconds=result['elapsed_seconds'],
                total_tokens_per_second=result['total_tokens_per_second'],
                mean_ttft_seconds=result['mean_ttft_seconds']))
        prior=json.loads((ROOT/'runtime-comparison.json').read_text())
        old=prior['results'][2]['total_tokens_per_second']
        mean=sum(x['total_tokens_per_second'] for x in results)/2
        summary=dict(results=results,old_warm_default=old,aligned_mean=mean,
                     relative_change=mean/old-1,official_score=False,
                     factors_changed=['required_tag_source','independent_compilation_caches'])
        (ROOT/'aligned-tag-comparison.json').write_text(json.dumps(summary,indent=2))
        state('aligned_tag_trial_complete_waiting_analysis',summary=summary)
    finally:
        if server.poll() is None:
            os.killpg(server.pid,signal.SIGTERM)
            try:
                server.wait(timeout=20)
            except subprocess.TimeoutExpired:
                os.killpg(server.pid,signal.SIGKILL);server.wait()
        stop.set();monitor.join(timeout=8)


if __name__=='__main__':
    try:
        main()
    except Exception as e:
        state('aligned_tag_trial_failed',error=repr(e))
        raise
