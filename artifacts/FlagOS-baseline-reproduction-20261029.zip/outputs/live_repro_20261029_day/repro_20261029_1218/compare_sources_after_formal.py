"""Optional bounded source comparison, AFTER all official workloads finish.

Diagnostic results are never competition scores. Original packages are unchanged.
"""
import asyncio
import json
import os
from pathlib import Path
import signal
import subprocess
import time
import requests
from diagnose import ROOT, URL, DEADLINE, workload, state


async def bounded_workload(seed):
    budget = min(600, DEADLINE-time.time()-30)
    if budget < 60:
        raise TimeoutError('Reserved time nearly exhausted')
    return await asyncio.wait_for(workload(64, 4096, 256, seed), timeout=budget)


def main():
    if time.time() > DEADLINE-1200:
        raise RuntimeError('Do not start: less than twenty reserved minutes remain')
    validated = json.loads((ROOT/'formal-independent-validation.json').read_text())
    assert validated['workloads_complete'] and validated['independent_validation']
    try:
        requests.get(URL+'/health', timeout=2)
    except requests.RequestException:
        pass
    else:
        raise RuntimeError('A service is still active; do not start a duplicate')
    target = ROOT/'post-formal-diagnostics'
    target.mkdir(exist_ok=False)
    (target/'prior-controller-status.json').write_text((ROOT/'status.json').read_text())
    pin = json.loads((ROOT/'aligned-runtime-environment.json').read_text())
    results = []
    for label, source in [('required_tag', pin['source_root']+'/src'),
                          ('preinstalled', '/usr/local/lib/python3.12/site-packages')]:
        if DEADLINE-time.time() < 600:
            state('post_formal_diagnostics_time_limited', completed_sources=len(results))
            break
        cache = Path('/workspace/tokenforge-caches/post_formal_20261029')/label
        assert not cache.exists(), 'Caches must start fresh for both source conditions'
        cache.mkdir(parents=True)
        env = dict(os.environ, VLLM_PLUGINS='fl', PYTHONPATH=source,
                   VLLM_CACHE_ROOT=str(cache/'vllm'), TRITON_CACHE_DIR=str(cache/'triton'),
                   TORCHINDUCTOR_CACHE_DIR=str(cache/'inductor'))
        imported = subprocess.check_output(['python', '-c',
            'import flag_gems; print(flag_gems.__file__)'], env=env, text=True)
        assert source in imported
        with (target/(label+'-server.log')).open('w') as f:
            server = subprocess.Popen(pin['argv'], env=env, stdin=subprocess.DEVNULL,
                                      stdout=f, stderr=subprocess.STDOUT, start_new_session=True)
        (target/(label+'-environment.json')).write_text(json.dumps(dict(
            source=source, imported=imported.strip(), cache=str(cache), argv=pin['argv'],
            server_pid=server.pid, official_score=False), indent=2))
        try:
            state('post_formal_'+label+'_starting', server_pid=server.pid)
            ready_by = min(time.time()+600, DEADLINE-60)
            while time.time() < ready_by:
                if server.poll() is not None:
                    raise RuntimeError('Diagnostic server exited')
                try:
                    if requests.get(URL+'/health', timeout=2).status_code == 200:
                        break
                except requests.RequestException:
                    pass
                time.sleep(5)
            else:
                raise TimeoutError('Diagnostic readiness budget exhausted')
            phase_results = []
            # Identical seeds and full shapes for both fresh-cache conditions.
            for phase, seed in [('warmup', 4100), ('measure_a', 4101), ('measure_b', 4102)]:
                state('post_formal_'+label+'_'+phase)
                result = asyncio.run(bounded_workload(seed))
                assert len(result['rows']) == 64
                assert all(r['usage']['prompt_tokens'] == 4096 and
                           r['usage']['completion_tokens'] == 256 for r in result['rows'])
                result['gpu_after_measurement'] = subprocess.check_output(
                    ['ixsmi', '-q', '-d', 'CLOCK,PERFORMANCE,POWER,UTILIZATION'], text=True, timeout=5)
                (target/(label+'-'+phase+'.json')).write_text(json.dumps(result, indent=2))
                if phase != 'warmup':
                    phase_results.append(dict(phase=phase, seconds=result['elapsed_seconds'],
                        total_tokens_per_second=64*(4096+256)/result['elapsed_seconds'],
                        mean_ttft_seconds=sum(r['ttft_seconds'] for r in result['rows'])/64))
            results.append(dict(source=label, measurements=phase_results,
                mean_total_tokens_per_second=sum(x['total_tokens_per_second'] for x in phase_results)/2))
        finally:
            if server.poll() is None:
                os.killpg(server.pid, signal.SIGTERM)
                try:
                    server.wait(timeout=20)
                except subprocess.TimeoutExpired:
                    os.killpg(server.pid, signal.SIGKILL)
                    server.wait()
    summary = dict(results=results, official_score=False, comparison_complete=len(results) == 2,
                   limitations='Sequential comparison with separate initially fresh caches; '
                   'one warmup and two measurements each. Time/order effects remain possible.')
    if len(results) == 2:
        summary['required_tag_relative_to_preinstalled'] = (
            results[0]['mean_total_tokens_per_second']/results[1]['mean_total_tokens_per_second']-1)
    (target/'summary.json').write_text(json.dumps(summary, indent=2))
    state('post_formal_diagnostics_complete', summary=summary)


if __name__ == '__main__':
    try:
        main()
    except Exception as e:
        state('post_formal_diagnostics_failed', error=repr(e))
        raise
