"""Unprofiled A/B/A CPU-affinity diagnosis; not an official benchmark score."""
import asyncio
import json
import os
from pathlib import Path
import signal
import subprocess
import threading
import time

import psutil
import requests
from diagnose import ROOT, URL, DEADLINE, state, telemetry, workload


def processes(pid):
    p = psutil.Process(pid)
    return [p] + p.children(recursive=True)


def apply_affinity(pid, cpus, saved=None):
    originals = {} if saved is None else saved
    changed = []
    for p in processes(pid):
        for entry in (Path('/proc')/str(p.pid)/'task').iterdir():
            tid = int(entry.name)
            try:
                if saved is None:
                    originals[tid] = sorted(os.sched_getaffinity(tid))
                    target = cpus
                else:
                    target = saved.get(tid, cpus)
                os.sched_setaffinity(tid, target)
                changed.append(tid)
            except ProcessLookupError:
                pass
    return originals, changed


def main():
    if time.time() > DEADLINE-1500:
        raise RuntimeError('Insufficient reserved time')
    try:
        requests.get(URL+'/health',timeout=2)
    except requests.RequestException:
        pass
    else:
        raise RuntimeError('Existing service; inspect before starting another')
    cmd = ['vllm','serve','/workspace/MiniCPM5-2B','--port','9031',
           '--compilation-config','{"cudagraph_mode":"FULL_DECODE_ONLY"}',
           '--served-model-name','minicpm','--gpu-memory-utilization','0.85',
           '--max-model-len','131072']
    with (ROOT/'runtime-server.log').open('w') as f:
        server = subprocess.Popen(cmd, env=dict(os.environ,VLLM_PLUGINS='fl'),
            stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
    (ROOT/'runtime-server.pid').write_text(str(server.pid))
    allowed = sorted(os.sched_getaffinity(server.pid))
    cpus = [x for x in range(6) if x in allowed]
    if len(cpus)!=6:
        raise RuntimeError('Expected local physical CPU cores unavailable')
    stop = threading.Event()
    monitor = threading.Thread(target=telemetry,args=(server.pid,stop),daemon=True)
    monitor.start()
    saved = None
    try:
        state('runtime_comparison_starting',server_pid=server.pid)
        ready_by = time.time()+900
        while time.time()<ready_by:
            if server.poll() is not None:
                raise RuntimeError('Runtime server exited')
            try:
                if requests.get(URL+'/health',timeout=3).status_code==200:
                    break
            except requests.RequestException:
                pass
            time.sleep(5)
        else:
            raise RuntimeError('Runtime service readiness timed out')
        state('runtime_warmup')
        asyncio.run(workload(64,512,64,2000))
        results = []
        for name,seed in [('default_a',2001),('numa_local',2002),('default_b',2003)]:
            if name=='numa_local':
                saved,changed = apply_affinity(server.pid,cpus)
                (ROOT/'affinity-change.json').write_text(json.dumps(dict(local_cpus=cpus,
                    original= saved, changed_tids=changed),indent=2))
            elif name=='default_b':
                apply_affinity(server.pid,allowed,saved)
                saved = None
            state('runtime_'+name)
            result = asyncio.run(workload(64,4096,256,seed))
            result['name']=name
            result['total_tokens_per_second'] = 64*(4096+256)/result['elapsed_seconds']
            result['mean_ttft_seconds'] = sum(x['ttft_seconds'] for x in result['rows'])/64
            (ROOT/('runtime-'+name+'.json')).write_text(json.dumps(result,indent=2))
            results.append({k:result[k] for k in ['name','elapsed_seconds',
                'total_tokens_per_second','mean_ttft_seconds','official_score']})
        baseline=(results[0]['total_tokens_per_second']+results[2]['total_tokens_per_second'])/2
        summary=dict(results=results,affinity_relative_to_default_mean=results[1]['total_tokens_per_second']/baseline-1,
                     official_score=False,note='Different workload from official benchmark; requires formal validation')
        (ROOT/'runtime-comparison.json').write_text(json.dumps(summary,indent=2))
        state('runtime_comparison_complete_waiting_analysis',summary=summary)
    finally:
        if server.poll() is None:
            if saved is not None:
                apply_affinity(server.pid,allowed,saved)
            os.killpg(server.pid,signal.SIGTERM)
            try:
                server.wait(timeout=20)
            except subprocess.TimeoutExpired:
                os.killpg(server.pid,signal.SIGKILL);server.wait()
        stop.set();monitor.join(timeout=8)


if __name__=='__main__':
    try:
        main()
    except Exception as e:
        state('runtime_comparison_failed',error=repr(e))
        raise
