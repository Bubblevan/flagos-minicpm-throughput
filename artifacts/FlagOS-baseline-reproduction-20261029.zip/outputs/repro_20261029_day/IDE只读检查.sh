#!/usr/bin/env bash
# Read-only checks: do not restart or stop any experiment.
R=/workspace/tokenforge-artifacts/repro_20261029_1218
date -Is
id
ps -eo pid,ppid,stat,etime,args | grep -E 'compare_official_tag|formal_reproduction|vllm serve|EngineCore' | grep -v grep
if [ -d "$R" ]; then
  cat "$R/status.json"
  tail -n 12 "$R/aligned-controller.log"
  tail -n 12 "$R/aligned-server.log"
  if [ -f "$R/aligned-tag-comparison.json" ]; then cat "$R/aligned-tag-comparison.json"; fi
else
  echo 'Expected experiment directory is missing; this may be a different or reset container.'
  ls -ld /workspace /workspace/tokenforge-artifacts 2>/dev/null
fi
