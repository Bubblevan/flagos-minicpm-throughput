$ErrorActionPreference = 'Continue'
$labTarget = 'lab_inst_01M60ANBE6KZQNS943VQF8QFFC@ssh.flagos.io'
$backupDir = Join-Path (Split-Path -Parent $PSScriptRoot) 'live_repro_20261029_day'
New-Item -ItemType Directory -Force -Path $backupDir | Out-Null
$endAt = [DateTimeOffset]::Parse('2026-10-29T18:02:00+08:00')
while ([DateTimeOffset]::Now -lt $endAt) {
    & scp -q -r -i C:/Users/bubblevan/.ssh/flagos_20261029 -o IdentitiesOnly=yes -o BatchMode=yes -o ConnectTimeout=12 -P 2224 "${labTarget}:/workspace/tokenforge-artifacts/repro_20261029_1218" $backupDir
    $artifactExitCode = $LASTEXITCODE
    & scp -q -r -i C:/Users/bubblevan/.ssh/flagos_20261029 -o IdentitiesOnly=yes -o BatchMode=yes -o ConnectTimeout=12 -P 2224 "${labTarget}:/workspace/benchmark_results" $backupDir
    $benchmarkExitCode = $LASTEXITCODE
    $record = $null
    $statusPath = Join-Path $backupDir 'repro_20261029_1218/status.json'
    if (Test-Path -LiteralPath $statusPath) {
        try { $record = Get-Content -LiteralPath $statusPath -Raw | ConvertFrom-Json } catch {}
    }
    $stage = if ($record) { $record.stage } else { 'unknown' }
    $accuracyExitCode = $null
    $accuracyExpected = ($stage -eq 'formal_accuracy_running' -or (Test-Path -LiteralPath (Join-Path $backupDir 'repro_20261029_1218/formal-accuracy.log')))
    if ($accuracyExpected) {
        & scp -q -r -i C:/Users/bubblevan/.ssh/flagos_20261029 -o IdentitiesOnly=yes -o BatchMode=yes -o ConnectTimeout=12 -P 2224 "${labTarget}:/workspace/evalscope-datasets/level3" $backupDir
        $accuracyExitCode = $LASTEXITCODE
    }
    [PSCustomObject]@{ last_attempt_at=[DateTimeOffset]::Now.ToString('o'); stage=$stage;
        artifact_exit_code=$artifactExitCode; benchmark_exit_code=$benchmarkExitCode;
        accuracy_expected=$accuracyExpected; accuracy_exit_code=$accuracyExitCode;
        backup_success=($artifactExitCode -eq 0 -and $benchmarkExitCode -eq 0 -and (-not $accuracyExpected -or $accuracyExitCode -eq 0)) } |
        ConvertTo-Json | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'local-sync-status.json') -Encoding utf8
    if ($artifactExitCode -eq 0 -and $benchmarkExitCode -eq 0 -and $stage -in @('investigation_finished','investigation_cutoff')) { break }
    Start-Sleep -Seconds 60
}

