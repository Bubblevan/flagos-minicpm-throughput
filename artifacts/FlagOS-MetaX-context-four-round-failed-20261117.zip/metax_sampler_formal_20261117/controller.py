"""One new original eight-round plus new105-question acceptance, gated on short A/B/A."""
import csv,datetime as dt,hashlib,json,os,shutil,signal,socket,subprocess,sys,threading,time,traceback
from pathlib import Path
import psutil,requests
BASE=Path(__file__).resolve().parent;sys.path.insert(0,str(BASE/'tools'))
import metax_campaign as m
from validate_accuracy_artifacts import audit
ROOT=Path('/data/tokenforge-artifacts/metax_sampler_formal_20261117')
SHORT=Path('/data/tokenforge-artifacts/metax_sampler_context_short_20261117_1345')
SOURCE=Path('/data/tokenforge-sources/TokenForge-context-candidate-20261117/vllm-plugin-FL')
END=dt.datetime.fromisoformat('2026-11-17T15:59:00+08:00').timestamp()
m.ROOT=ROOT;m.END=END
halt=threading.Event()
def telemetry():
    while not halt.wait(5):
        row=dict(at=time.time(),memory={n:(Path('/sys/fs/cgroup')/n).read_text() for n in ['memory.current','memory.events','memory.pressure','cpu.stat']})
        row['owned']=[]
        for parent in m.children:
            try:
                for p in [psutil.Process(parent.pid)]+psutil.Process(parent.pid).children(recursive=True):
                    row['owned'].append(dict(pid=p.pid,created=p.create_time(),name=p.name(),rss=p.memory_info().rss))
            except psutil.Error:pass
        with (ROOT/'telemetry.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
def main():
    assert END-time.time()>75*60,'No full acceptance without completion budget'
    assert json.loads((BASE/'cpu-client-http-smoke.json').read_text())['pass']
    summary=json.loads((SHORT/'short-summary.json').read_text());assert summary['complete'] and summary['short_go']
    clean=json.loads((SHORT/'cleanup.json').read_text());assert not clean['owned_survivors']
    with socket.socket() as s:assert s.connect_ex(('127.0.0.1',9031))!=0
    gpu=m.command(['mx-smi']);assert 'no process found' in gpu.lower()
    manifest=json.loads((SHORT/'source-manifest.json').read_text())
    for f,h in manifest['files'].items():assert hashlib.sha256((SOURCE/f).read_bytes()).hexdigest()==h
    assert m.command(['git','-C','/workspace/vllm-plugin-FL','rev-parse','HEAD'])=='13eb9be69ecc5b5ca4f79c44e9ee40081eaa1bf0'
    assert not m.command(['git','-C','/workspace/vllm-plugin-FL','status','--porcelain'])
    assert not m.command(['git','-C','/workspace/FlagGems','status','--porcelain'])
    assert m.command(['git','-C','/workspace/FlagGems','rev-parse','HEAD'])=='a7620cc191a0b42e040194622c5758b22a7a25dc'
    bench=Path('/workspace/vllm-plugin-FL/benchmarks/benchmark_throughput_serve.py')
    assert hashlib.sha256(bench.read_bytes()).hexdigest()=='0813eba574e9d1eb50c297c515baa426da1bcb61ce8c78a398b482f246005565'
    combined=SOURCE.parent
    full_manifest=json.loads((combined/'candidate-source-manifest.json').read_text())
    for f,h in full_manifest['files'].items():assert hashlib.sha256((SOURCE/f).read_bytes()).hexdigest()==h
    assert json.loads((combined/'difference-to-tested-metax-source.json').read_text())['metax_source_identical']
    ROOT.mkdir(parents=True,exist_ok=False)
    shutil.copy2(combined/'candidate-source-manifest.json',ROOT/'full-source-manifest.json')
    shutil.copy2(combined/'difference-to-tested-metax-source.json',ROOT/'difference-to-short-source.json')
    shutil.copy2(BASE/'cpu-client-http-smoke.json',ROOT/'cpu-client-http-smoke.json')
    shutil.copy2(BASE/'formal-decision-preregistered.json',ROOT/'acceptance-decision.json')
    for name in ['short-summary.json','source-manifest.json','shadow-proof.json','plan.json']:shutil.copy2(SHORT/name,ROOT/('preflight-'+name))
    shutil.copy2(__file__,ROOT/'controller.py')
    for f in manifest['files']:
        p=ROOT/'modified-source'/f;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(SOURCE/f,p)
    cache=Path('/data/tokenforge-caches')/ROOT.name
    for n in ['triton','vllm','inductor']:
        old=Path('/data/tokenforge-caches')/SHORT.name/n
        if old.exists():shutil.copytree(old,cache/n)
    m.write('cache-origin.json',dict(source='same-device matched short trial cache; original four-round protocol unchanged',official_rounds_unchanged=True,cache_is_not_original_optimization=True))
    env=dict(os.environ,VLLM_PLUGINS='fl',PYTHONPATH=str(SOURCE),TORCHINDUCTOR_COMPILE_THREADS='1',FLAGOS_SESSION_ROOT=str(ROOT),
        FLAGOS_METAX_TOPP_MODE='candidate',PYTHONDONTWRITEBYTECODE='1',VLLM_CACHE_ROOT=str(cache/'vllm'),TRITON_CACHE_DIR=str(cache/'triton'),TORCHINDUCTOR_CACHE_DIR=str(cache/'inductor'))
    env.pop('FLAGOS_METAX_TOPP_DIAGNOSTIC_CONTROL',None);env.pop('VLLM_SERVER_DEV_MODE',None)
    argv=['vllm','serve','/workspace/MiniCPM5-2B','--port','9031','--served-model-name','minicpm','--gpu-memory-utilization','0.85','--max-model-len','131072']
    proof=m.command([sys.executable,'-c','import vllm_fl,flag_gems;print(vllm_fl.__file__);print(flag_gems.__file__);import torch._inductor.config as c;print(c.compile_threads)'],env=env)
    assert str(SOURCE) in proof and proof.endswith('1')
    m.write('plan.json',dict(platform='metax_c500_64gb',cutoff_epoch=END,official_serve_argv=argv,benchmark_sha256=hashlib.sha256(bench.read_bytes()).hexdigest(),
        candidate='context_guarded_mass_certified_nucleus_shortlist_plus_prefix_metadata_hoist',full_source_restoration_test=True,prior_negative_short_gates_preserved=True,abort_partial_session_on_complete_4k_failure=True,short_gate=summary,
        sampling_policy_unchanged=True,model_data_precision_unchanged=True,RNG_implementation_unchanged=True,
        environment_repairs=['Single Inductor compiler process','HTTP benchmark client uses vLLM supported CPU platform without GPU plugin; EvalScope HTTP client also hides GPU'],environment_repairs_not_original_optimization=True))
    metadata=m.command([sys.executable,'-c',"import importlib.metadata as m,json; print(json.dumps({n:m.version(n) for n in ['torch','vllm','vllm-plugin-FL','flag-gems','triton','evalscope']}))"],env=env)
    m.write('packages.json',json.loads(metadata))
    config=Path('/workspace/MiniCPM5-2B/config.json');m.write('model-config.json',dict(path=str(config),sha256=hashlib.sha256(config.read_bytes()).hexdigest(),config=json.loads(config.read_text())))
    m.write('gems-identity.json',dict(head=m.command(['git','-C','/workspace/FlagGems','rev-parse','HEAD']),tree=m.command(['git','-C','/workspace/FlagGems','write-tree']),clean=True))
    m.write('runtime.json',dict(import_proof=proof,source_manifest=manifest,environment={k:env[k] for k in ['VLLM_PLUGINS','PYTHONPATH','TORCHINDUCTOR_COMPILE_THREADS','FLAGOS_SESSION_ROOT','FLAGOS_METAX_TOPP_MODE']},gpu=gpu,hostname=os.uname().nodename))
    threading.Thread(target=telemetry,daemon=True).start()
    server=m.spawn(argv,env,'server.log',Path('/workspace'));m.state('server_starting',server_pid=server.pid)
    ready_by=min(time.time()+600,END-65*60)
    while time.time()<ready_by:
        if server.poll() is not None:raise RuntimeError('Service exited')
        try:
            if requests.get('http://127.0.0.1:9031/health',timeout=2).status_code==200:break
        except requests.RequestException:pass
        time.sleep(3)
    else:raise TimeoutError('No readiness within acceptance budget')
    # This child sends HTTP and tokenizes text only. Original script/argv/request
    # generation are unchanged. CPU environment avoids a redundant21GiB GPU runtime.
    client_env=dict(env,VLLM_PLUGINS='',CUDA_VISIBLE_DEVICES='',MACA_VISIBLE_DEVICES='')
    folder=ROOT/'official-benchmark';folder.mkdir()
    args=[sys.executable,str(bench),'--model','/workspace/MiniCPM5-2B','--served-model-name','minicpm','--port','9031','--test-cases','[[4096,1024,64,256],[16384,1024,64,128]]']
    m.state('official-benchmark',argv=args)
    client=m.spawn(args,client_env,'official-benchmark.log',folder)
    benchmark_end=min(time.time()+3300,END-20*60)
    checked_4k=False
    while client.poll() is None:
        if time.time()>benchmark_end:raise TimeoutError('Original benchmark exceeds full acceptance budget')
        if not checked_4k:
            raws=list((folder/'benchmark_results').glob('raw_runs_*.csv'))
            if len(raws)==1:
                rows=list(csv.DictReader(raws[0].open()))
                four=[r for r in rows if r.get('Prefill')=='4096']
                if len(four)==4 and all(r.get('Total tok/s') and r.get('Mean TTFT (ms)') for r in four):
                    assert all(r['Run Status']=='SUCCESS' and int(float(r['Successful Requests']))==256 and int(float(r['Total Input Tokens']))==4096*256 and int(float(r['Total Output Tokens']))==1024*256 for r in four)
                    tps=sum(float(r['Total tok/s']) for r in four[1:])/3
                    ttft=sum(float(r['Mean TTFT (ms)']) for r in four[1:])/3
                    ok=tps>=5089.645*.99 and ttft<=3199.435*1.01
                    m.write('4k-interim-validation.json',dict(complete_four_rounds=True,total_tokens_per_second=tps,mean_ttft_ms=ttft,pass_=ok,overall_pass_established=False,policy='Stop own partial session on proven4K failure; never splice or call it eight-round completion'))
                    checked_4k=True
                    if not ok:raise RuntimeError('Complete4Kcase already fails: stop this partial session to preserve remaining optimization budget')
        time.sleep(3)
    assert client.returncode==0,('official-benchmark',client.returncode)
    perf=m.perf(folder);m.write('performance-validation.json',perf)
    assert perf['performance_pass'],'Formal performance fails: preserve raw results, no passing claim'
    assert END-time.time()>18*60,'Insufficient new105question budget'
    m.run('official-accuracy',['bash',str(BASE/'tools/run_official_accuracy.sh')],END-time.time()-45,dict(client_env,FLAGOS_EVAL_WORK_DIR=str(ROOT/'evalscope')),ROOT)
    reports=list((ROOT/'evalscope').glob('*/reports/minicpm/math_500.json'));assert len(reports)==1
    accuracy=audit(reports[0].parents[2]);m.write('accuracy-audit.json',accuracy)
    m.write('independent-result.json',dict(platform='metax_c500_64gb',performance=perf,accuracy_audit=accuracy,source_manifest=manifest,
        performance_pass=perf['performance_pass'],accuracy_pass=accuracy['accuracy_pass'],workloads_complete=accuracy['integrity_pass'],
        overall_pass=bool(perf['performance_pass'] and accuracy['accuracy_pass'] and accuracy['integrity_pass']),completed=time.time()))
    m.state('complete_needs_local_audit')
if __name__=='__main__':
    def interrupted(*_):raise TimeoutError('Authorized2.5h cutoff')
    signal.signal(signal.SIGALRM,interrupted);signal.signal(signal.SIGTERM,interrupted);signal.alarm(max(1,int(END-time.time())))
    failure=None
    try:main()
    except BaseException as e:
        failure=dict(error=repr(e),traceback=traceback.format_exc());print(traceback.format_exc(),flush=True)
        if ROOT.exists():m.write('failure.json',failure)
    finally:
        signal.alarm(0);survivors=[]
        for p in reversed(m.children):survivors+=m.stop(p)
        halt.set()
        if ROOT.exists():m.state('stopped',failure=failure,owned_survivors=survivors)
