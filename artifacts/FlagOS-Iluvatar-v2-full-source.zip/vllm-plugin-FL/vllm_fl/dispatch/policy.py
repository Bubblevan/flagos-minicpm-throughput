# Copyright (c) 2026 BAAI. All rights reserved.

"""
Selection policy management for operator dispatch.
"""

from __future__ import annotations

import contextvars
import logging
import os
import threading
import yaml
from dataclasses import dataclass, field
from typing import Any, Dict, FrozenSet, List, Optional, Set, Tuple


from vllm_fl.utils import get_op_config


logger = logging.getLogger(__name__)


# Valid preference values for VLLM_FL_PREFER
PREFER_DEFAULT = "flagos"
PREFER_VENDOR = "vendor"
PREFER_REFERENCE = "reference"

VALID_PREFER_VALUES = frozenset({PREFER_DEFAULT, PREFER_VENDOR, PREFER_REFERENCE})


@dataclass(frozen=True)
class SelectionPolicy:
    """
    Policy for selecting operator implementations.

    Attributes:
        prefer: Which implementation kind to prefer. One of:
            - "flagos": Prefer DEFAULT (FlagOS) implementations
            - "vendor": Prefer VENDOR (CUDA) implementations
            - "reference": Prefer REFERENCE (PyTorch) implementations
        strict: If True, raise error when primary implementation fails
        per_op_order: Per-operator custom selection order
        deny_vendors: Set of vendor names to deny
        allow_vendors: Set of vendor names to allow (whitelist)
    """

    prefer: str = PREFER_DEFAULT
    strict: bool = False
    per_op_order: Tuple[Tuple[str, Tuple[str, ...]], ...] = field(default_factory=tuple)
    deny_vendors: FrozenSet[str] = field(default_factory=frozenset)
    allow_vendors: Optional[FrozenSet[str]] = None

    def __post_init__(self):
        if self.prefer not in VALID_PREFER_VALUES:
            raise ValueError(
                f"Invalid prefer value: '{self.prefer}'. "
                f"Must be one of: {', '.join(sorted(VALID_PREFER_VALUES))}"
            )

    @classmethod
    def from_dict(
        cls,
        prefer: str = PREFER_DEFAULT,
        strict: bool = False,
        per_op_order: Optional[Dict[str, List[str]]] = None,
        deny_vendors: Optional[Set[str]] = None,
        allow_vendors: Optional[Set[str]] = None,
    ) -> "SelectionPolicy":
        """Create a SelectionPolicy from dictionary-like arguments."""
        per_op_tuple = tuple()
        if per_op_order:
            per_op_tuple = tuple((k, tuple(v)) for k, v in sorted(per_op_order.items()))

        return cls(
            prefer=prefer.lower(),
            strict=strict,
            per_op_order=per_op_tuple,
            deny_vendors=frozenset(deny_vendors) if deny_vendors else frozenset(),
            allow_vendors=frozenset(allow_vendors) if allow_vendors else None,
        )

    @property
    def per_op_order_dict(self) -> Dict[str, List[str]]:
        """Get per_op_order as a mutable dict for easier access."""
        return {k: list(v) for k, v in self.per_op_order}

    def get_per_op_order(self, op_name: str) -> Optional[List[str]]:
        """Get order for a specific operator."""
        for name, order in self.per_op_order:
            if name == op_name:
                return list(order)
        return None

    def get_default_order(self) -> List[str]:
        """Get the default selection order based on preference setting."""
        if self.prefer == PREFER_REFERENCE:
            return ["reference", "flagos", "vendor"]
        elif self.prefer == PREFER_VENDOR:
            return ["vendor", "flagos", "reference"]
        else:  # PREFER_DEFAULT
            return ["flagos", "vendor", "reference"]

    def is_vendor_allowed(self, vendor_name: str) -> bool:
        """Check if a vendor is allowed by this policy."""
        if vendor_name in self.deny_vendors:
            return False
        if self.allow_vendors is not None and vendor_name not in self.allow_vendors:
            return False
        return True

    def fingerprint(self) -> str:
        """Generate a unique fingerprint for this policy (used for caching)."""
        parts = [
            f"prefer={self.prefer}",
            f"st={int(self.strict)}",
        ]

        if self.allow_vendors:
            parts.append(f"allow={','.join(sorted(self.allow_vendors))}")

        if self.deny_vendors:
            parts.append(f"deny={','.join(sorted(self.deny_vendors))}")

        if self.per_op_order:
            per_op_str = ";".join(f"{k}={'|'.join(v)}" for k, v in self.per_op_order)
            parts.append(f"per={per_op_str}")

        return ";".join(parts)

    def __hash__(self) -> int:
        return hash(
            (
                self.prefer,
                self.strict,
                self.per_op_order,
                self.deny_vendors,
                self.allow_vendors,
            )
        )


class PolicyManager:
    """
    Singleton manager for selection policies.

    Supports:
    - Global policy (from environment or set programmatically)
    - Context-local policy (using context managers)
    - Policy epoch tracking for cache invalidation
    """

    _instance = None
    _lock = threading.Lock()

    def __init__(self):
        if hasattr(self, "_policy_epoch"):
            return

        self._policy_epoch = 0
        self._policy_epoch_lock = threading.Lock()
        self._global_policy = None
        self._global_policy_lock = threading.Lock()

        self._policy_var = contextvars.ContextVar(
            "vllm_fl_selection_policy",
            default=None,
        )

    @classmethod
    def get_instance(cls):
        """Get the singleton instance."""
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = cls.__new__(cls)
                    cls._instance.__init__()
        return cls._instance

    def get_policy_epoch(self) -> int:
        """Get the current policy epoch."""
        return self._policy_epoch

    def bump_policy_epoch(self) -> int:
        """Bump the policy epoch and return the new value."""
        with self._policy_epoch_lock:
            self._policy_epoch += 1
            return self._policy_epoch

    def get_policy(self) -> SelectionPolicy:
        """Get the current effective policy (context or global)."""
        ctx_policy = self._policy_var.get()
        if ctx_policy is not None:
            return ctx_policy

        if self._global_policy is None:
            with self._global_policy_lock:
                if self._global_policy is None:
                    self._global_policy = self._policy_from_env()
        return self._global_policy

    def set_global_policy(self, policy: SelectionPolicy) -> SelectionPolicy:
        """Set the global policy and return the old policy."""
        with self._global_policy_lock:
            old_policy = self._global_policy
            self._global_policy = policy
            self.bump_policy_epoch()
            return old_policy if old_policy else self._policy_from_env()

    def reset_global_policy(self) -> None:
        """Reset the global policy to environment defaults."""
        with self._global_policy_lock:
            self._global_policy = None
            self.bump_policy_epoch()

    def create_policy_context(self, policy: SelectionPolicy):
        """Create a context manager for temporary policy override."""
        return _PolicyContext(self, policy)

    def _get_policy_var(self):
        return self._policy_var

    @staticmethod
    def _parse_csv_set(value: str) -> Set[str]:
        """Parse a comma-separated string into a set."""
        if not value:
            return set()
        return {x.strip() for x in value.split(",") if x.strip()}

    @staticmethod
    def _parse_per_op(value: str) -> Dict[str, List[str]]:
        """Parse per-op order string (format: op1=a|b|c;op2=x|y)."""
        if not value:
            return {}

        result: Dict[str, List[str]] = {}
        parts = [p.strip() for p in value.split(";") if p.strip()]

        for part in parts:
            if "=" not in part:
                continue
            op_name, order_str = part.split("=", 1)
            op_name = op_name.strip()
            order = [x.strip() for x in order_str.split("|") if x.strip()]
            if op_name and order:
                result[op_name] = order

        return result

    def _policy_from_config(self, config_path: str) -> SelectionPolicy:
        """
        Create a SelectionPolicy from a YAML configuration file.

        Args:
            config_path: Path to the YAML configuration file.

        Returns:
            SelectionPolicy loaded from the config file.

        Raises:
            FileNotFoundError: If the config file does not exist.
            ValueError: If the config file cannot be parsed.

        Config file format (YAML):
            # Optional action for tooling (e.g., auto_tune)
            action: auto_tune

            # Preferred backend type: flagos, vendor, or reference
            prefer: vendor

            # Strict mode:
            #   true  = fail immediately on error, no fallback
            #   false = try next backend on failure (default)
            strict: true

            # Vendor whitelist (optional)
            allow_vendors:
              - cuda

            # Vendor blacklist (optional)
            deny_vendors:
              - ascend

            # Per-operator backend selection order (optional)
            # Only the backends listed will be tried, in the specified order.
            # If you only list 2 options, only those 2 will be attempted.
            #
            # Supported tokens:
            #   - flagos        : FlagOS default implementation
            #   - reference     : PyTorch reference implementation
            #   - vendor        : Any available vendor backend (auto-detect)
            #   - vendor:cuda   : Only CUDA vendor backend
            #   - vendor:ascend : Only Ascend vendor backend
            op_backends:
              rms_norm:
                - vendor        # Try any available vendor first
                - flagos        # Then try flagos
                # reference not listed, so it won't be used

              silu_and_mul:
                - vendor:cuda   # Only try CUDA, not other vendors
                - flagos
                - reference
        """
        if not os.path.isfile(config_path):
            raise FileNotFoundError(f"Config file '{config_path}' not found.")

        try:
            with open(config_path, "r", encoding="utf-8") as f:
                config: Dict[str, Any] = yaml.safe_load(f) or {}
        except Exception as e:
            raise ValueError(f"Failed to load config file '{config_path}': {e}") from e

        # Parse prefer
        prefer_str = str(config.get("prefer", PREFER_DEFAULT)).strip().lower()
        if prefer_str not in VALID_PREFER_VALUES:
            prefer_str = PREFER_DEFAULT

        # Parse strict
        strict_val = config.get("strict", False)
        strict = bool(strict_val)

        # Parse deny_vendors
        deny_vendors_raw = config.get("deny_vendors")
        deny_vendors: Optional[Set[str]] = None
        if deny_vendors_raw:
            if isinstance(deny_vendors_raw, list):
                deny_vendors = {str(v).strip() for v in deny_vendors_raw if v}
            elif isinstance(deny_vendors_raw, str):
                deny_vendors = self._parse_csv_set(deny_vendors_raw)

        # Parse allow_vendors
        allow_vendors_raw = config.get("allow_vendors")
        allow_vendors: Optional[Set[str]] = None
        if allow_vendors_raw:
            if isinstance(allow_vendors_raw, list):
                allow_vendors = {str(v).strip() for v in allow_vendors_raw if v}
            elif isinstance(allow_vendors_raw, str):
                allow_vendors = self._parse_csv_set(allow_vendors_raw)

        # Parse op_backends
        per_op_raw = config.get("op_backends")
        per_op_order: Optional[Dict[str, List[str]]] = None
        if per_op_raw and isinstance(per_op_raw, dict):
            per_op_order = {}
            for op_name, order in per_op_raw.items():
                if isinstance(order, list):
                    per_op_order[str(op_name)] = [str(o).strip() for o in order if o]
                elif isinstance(order, str):
                    # Support string format: "vendor:cuda|flagos"
                    per_op_order[str(op_name)] = [
                        o.strip() for o in order.split("|") if o.strip()
                    ]

        logger.info("Using custom config from '%s'", config_path)

        return SelectionPolicy.from_dict(
            prefer=prefer_str,
            strict=strict,
            per_op_order=per_op_order,
            deny_vendors=deny_vendors,
            allow_vendors=allow_vendors,
        )

    @staticmethod
    def _parse_op_config(value: Dict[str, str]) -> Dict[str, List[str]]:
        """Parse op config dict into per-op order."""
        result: Dict[str, List[str]] = {}
        for op_name, backend in value.items():
            key = backend.strip().lower()
            if key not in VALID_PREFER_VALUES:
                raise ValueError(f"Unsupported backend '{backend}' for op '{op_name}'.")
            result[op_name] = [key]
        return result

    def _policy_from_env(self) -> SelectionPolicy:
        """
        Create a SelectionPolicy from configuration file or environment variables.

        Priority (highest to lowest):
        1. VLLM_FL_CONFIG: Path to YAML config file (if set, completely overrides)
        2. Environment variables: Override specific items from platform config
        3. Platform-specific config file: Default values (auto-detected)
        4. Built-in default values

        Environment variables:
        - VLLM_FL_CONFIG: Path to YAML configuration file (complete override)
        - VLLM_FL_PREFER: Preference (flagos, vendor, reference)
        - VLLM_FL_STRICT: Strict mode: 1 = fail immediately on error (no fallback), 0 = try fallback (default)
        - VLLM_FL_DENY_VENDORS: Comma-separated list of denied vendors
        - VLLM_FL_ALLOW_VENDORS: Comma-separated list of allowed vendors
        - VLLM_FL_PER_OP: Per-op order (format: op1=a|b|c;op2=x|y)
        """
        # Priority 1: Check for user-specified config file (complete override)
        config_path = os.environ.get("VLLM_FL_CONFIG", "").strip()
        if config_path and os.path.isfile(config_path):
            return self._policy_from_config(config_path)

        # Priority 3: Load platform-specific config as base defaults
        from vllm_fl.dispatch.config import get_config_path
        platform_config_path = get_config_path()
        platform_policy = None
        if platform_config_path:
            try:
                platform_policy = self._policy_from_config(str(platform_config_path))
            except Exception as e:
                logger.warning("Failed to load platform config: %s", e)

        # Priority 2: Environment variables override platform config
        # Get values from environment variables
        env_prefer_str = os.environ.get("VLLM_FL_PREFER", "").strip().lower()
        env_strict_str = os.environ.get("VLLM_FL_STRICT", "0").strip()
        env_deny_str = os.environ.get("VLLM_FL_DENY_VENDORS", "").strip()
        env_allow_str = os.environ.get("VLLM_FL_ALLOW_VENDORS", "").strip()
        env_per_op_str = os.environ.get("VLLM_FL_PER_OP", "").strip()

        # Determine final values: env var > platform config > default
        if env_prefer_str and env_prefer_str in VALID_PREFER_VALUES:
            prefer_str = env_prefer_str
        elif platform_policy:
            prefer_str = platform_policy.prefer
        else:
            prefer_str = PREFER_DEFAULT

        if env_strict_str:
            if env_strict_str not in ("0", "1"):
                logger.warning(
                    f"Invalid VLLM_FL_STRICT value '{env_strict_str}', "
                    f"expected '0' or '1'. Defaulting to '0' (fallback mode)."
                )
                strict = False
            else:
                strict = env_strict_str == "1"
        elif platform_policy:
            strict = platform_policy.strict
        else:
            strict = False

        if env_deny_str:
            deny_vendors = self._parse_csv_set(env_deny_str)
        elif platform_policy and platform_policy.deny_vendors:
            deny_vendors = set(platform_policy.deny_vendors)
        else:
            deny_vendors = None

        if env_allow_str:
            allow_vendors = self._parse_csv_set(env_allow_str)
        elif platform_policy and platform_policy.allow_vendors:
            allow_vendors = set(platform_policy.allow_vendors)
        else:
            allow_vendors = None

        # Per-op order: env var > op_config > platform config
        op_config = get_op_config()
        if op_config:
            per_op_order = self._parse_op_config(op_config)
        elif env_per_op_str:
            per_op_order = self._parse_per_op(env_per_op_str)
        elif platform_policy and platform_policy.per_op_order:
            per_op_order = platform_policy.per_op_order_dict
        else:
            per_op_order = None

        return SelectionPolicy.from_dict(
            prefer=prefer_str,
            strict=strict,
            per_op_order=per_op_order,
            deny_vendors=deny_vendors,
            allow_vendors=allow_vendors,
        )


class _PolicyContext:
    """Context manager for temporary policy override."""

    def __init__(self, manager: PolicyManager, policy: SelectionPolicy):
        self._manager = manager
        self._policy = policy
        self._token: Optional[contextvars.Token] = None

    def __enter__(self) -> "_PolicyContext":
        policy_var = self._manager._get_policy_var()
        self._token = policy_var.set(self._policy)
        self._manager.bump_policy_epoch()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        if self._token is not None:
            policy_var = self._manager._get_policy_var()
            policy_var.reset(self._token)
            self._manager.bump_policy_epoch()


# Convenience functions for easier access
def get_policy_epoch() -> int:
    """Get the current policy epoch."""
    return PolicyManager.get_instance().get_policy_epoch()


def bump_policy_epoch() -> int:
    """Bump the policy epoch and return the new value."""
    return PolicyManager.get_instance().bump_policy_epoch()


def get_policy() -> SelectionPolicy:
    """Get the current effective policy (context or global)."""
    return PolicyManager.get_instance().get_policy()


def set_global_policy(policy: SelectionPolicy) -> SelectionPolicy:
    """Set the global policy and return the old policy."""
    return PolicyManager.get_instance().set_global_policy(policy)


def reset_global_policy() -> None:
    """Reset the global policy to environment defaults."""
    PolicyManager.get_instance().reset_global_policy()


def policy_from_env() -> SelectionPolicy:
    """Create a SelectionPolicy from configuration file or environment variables."""
    return PolicyManager.get_instance()._policy_from_env()


def policy_from_config(config_path: str) -> SelectionPolicy:
    """
    Create a SelectionPolicy from a YAML configuration file.

    Args:
        config_path: Path to the YAML configuration file.

    Returns:
        SelectionPolicy loaded from the config file.

    Raises:
        FileNotFoundError: If the config file does not exist.
        ValueError: If the config file cannot be parsed.

    Example config file (YAML):
        # Preferred backend type: flagos, vendor, or reference
        prefer: vendor

        # Strict mode: true = fail immediately on error, false = try next backend
        strict: true

        # Vendor whitelist (optional)
        allow_vendors:
          - cuda

        # Vendor blacklist (optional)
        deny_vendors:
          - ascend

        # Per-operator backend selection order (optional)
        # Only the backends listed will be tried, in the specified order.
        # If you only list 2 options, only those 2 will be attempted.
        #
        # Supported tokens:
        #   - flagos        : FlagOS default implementation
        #   - reference     : PyTorch reference implementation
        #   - vendor        : Any available vendor backend (auto-detect)
        #   - vendor:cuda   : Only CUDA vendor backend
        #   - vendor:ascend : Only Ascend vendor backend
        op_backends:
          rms_norm:
            - vendor        # Try any available vendor first
            - flagos        # Then try flagos
            # reference not listed, so it won't be used for rms_norm

          silu_and_mul:
            - vendor:cuda   # Only try CUDA, not other vendors
            - flagos
            - reference
    """
    return PolicyManager.get_instance()._policy_from_config(config_path)


def policy_context(policy: SelectionPolicy) -> _PolicyContext:
    """
    Create a context manager to temporarily override the policy.

    Example:
        >>> with policy_context(my_policy):
        ...     # Use my_policy in this context
        ...     result = manager.resolve("op_name")
    """
    return _PolicyContext(PolicyManager.get_instance(), policy)


# Convenience context managers
def with_strict_mode() -> _PolicyContext:
    """Context manager to enable strict mode."""
    current = get_policy()
    strict_policy = SelectionPolicy.from_dict(
        prefer=current.prefer,
        strict=True,
        per_op_order={k: list(v) for k, v in current.per_op_order},
        deny_vendors=set(current.deny_vendors),
        allow_vendors=set(current.allow_vendors) if current.allow_vendors else None,
    )
    return policy_context(strict_policy)


def with_preference(prefer: str) -> _PolicyContext:
    """
    Context manager to set implementation preference.

    Args:
        prefer: One of "flagos", "vendor", or "reference"

    Example:
        >>> with with_preference("vendor"):
        ...     # Prefer vendor implementations in this context
        ...     result = manager.resolve("op_name")
    """
    current = get_policy()
    policy = SelectionPolicy.from_dict(
        prefer=prefer,
        strict=current.strict,
        per_op_order={k: list(v) for k, v in current.per_op_order},
        deny_vendors=set(current.deny_vendors),
        allow_vendors=set(current.allow_vendors) if current.allow_vendors else None,
    )
    return policy_context(policy)


def with_allowed_vendors(*vendors: str) -> _PolicyContext:
    """Context manager to set allowed vendors whitelist."""
    current = get_policy()
    policy = SelectionPolicy.from_dict(
        prefer=current.prefer,
        strict=current.strict,
        per_op_order={k: list(v) for k, v in current.per_op_order},
        deny_vendors=set(current.deny_vendors),
        allow_vendors=set(vendors),
    )
    return policy_context(policy)


def with_denied_vendors(*vendors: str) -> _PolicyContext:
    """Context manager to add denied vendors to blacklist."""
    current = get_policy()
    denied = set(current.deny_vendors)
    denied.update(vendors)
    policy = SelectionPolicy.from_dict(
        prefer=current.prefer,
        strict=current.strict,
        per_op_order={k: list(v) for k, v in current.per_op_order},
        deny_vendors=denied,
        allow_vendors=set(current.allow_vendors) if current.allow_vendors else None,
    )
    return policy_context(policy)
