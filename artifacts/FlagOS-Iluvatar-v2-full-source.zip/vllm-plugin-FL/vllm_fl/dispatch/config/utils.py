
# Copyright (c) 2026 BAAI. All rights reserved.

"""
Hardware-specific operator configuration loader utilities.

This module provides automatic loading of operator configurations based on
the detected hardware platform.

Configuration Priority (highest to lowest):
1. VLLM_FL_CONFIG: User-specified config file path (complete override)
2. Environment variables: Override specific items from platform config
   - VLLM_FL_PREFER: Backend preference (flagos, vendor, reference)
   - VLLM_FL_STRICT: Strict mode: 1 = fail immediately on error (no fallback), 0 = try fallback (default)
   - VLLM_FL_PER_OP: Per-operator backend order
   - VLLM_FL_FLAGOS_BLACKLIST: FlagOS operator blacklist
   - VLLM_FL_OOT_BLACKLIST: OOT operator blacklist
3. Platform-specific config file: Default values (auto-detected)
4. Built-in default values

Supported platforms:
- ascend: Huawei Ascend NPU
- cuda: NVIDIA GPU
- (more platforms can be added)

Configuration files are stored in this directory as YAML files:
- ascend.yaml
- cuda.yaml
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Optional

import yaml
from vllm_fl.utils import VENDOR_DEVICE_MAP

# Directory containing config files (config/)
_CONFIG_DIR = Path(__file__).parent


def _get_arch_config_name(platform: str) -> Optional[str]:
    """Return an architecture-specific config name when one is available."""
    if platform != "nvidia":
        return None
    if os.environ.get("VLLM_FL_HOPPER_LONG_CONTEXT_OPT", "0").lower() not in (
        "1",
        "true",
    ):
        return None

    try:
        from vllm.platforms import current_platform

        capability = current_platform.get_device_capability()
    except Exception:
        # Device discovery is not guaranteed to be available in API-only or
        # model-inspection processes. Fall back to the vendor-wide defaults.
        return None

    if capability is not None and capability.major == 9:
        return "nvidia_hopper"
    return None


def get_platform_name() -> str:
    """
    Detect the current hardware platform.

    Returns:
        Platform name string: 'ascend', 'iluvatar', 'musa', 'cuda', or 'unknown'
    """
    try:
        from vllm.platforms import current_platform
        return current_platform.vendor_name
    except ImportError:
        pass

    # Check environment variable override
    platform_override = os.environ.get('VLLM_FL_PLATFORM', '').strip().lower()
    if platform_override:
        return platform_override

    return 'unknown'


def get_config_path(platform: Optional[str] = None) -> Optional[Path]:
    """
    Get the configuration file path for the specified or detected platform.

    Args:
        platform: Platform name. If None, auto-detect.

    Returns:
        Path to the config file, or None if not found.
    """
    if platform is None:
        platform = get_platform_name()

    arch_config = _get_arch_config_name(platform)
    if arch_config is not None:
        config_file = _CONFIG_DIR / f"{arch_config}.yaml"
        if config_file.exists():
            return config_file

    # Try platform-specific config
    config_file = _CONFIG_DIR / f"{platform}.yaml"
    if config_file.exists():
        return config_file

    return None


def load_platform_config(platform: Optional[str] = None) -> Optional[dict[str, Any]]:
    """
    Load the configuration for the specified or detected platform.

    Args:
        platform: Platform name. If None, auto-detect.

    Returns:
        Configuration dictionary, or None if no config found.
    """
    config_path = get_config_path(platform)
    if config_path is None:
        return None

    try:
        with open(config_path, 'r', encoding='utf-8') as f:
            config = yaml.safe_load(f)
        return config if isinstance(config, dict) else None
    except Exception:
        return None


def get_per_op_order(config: Optional[dict] = None) -> Optional[dict[str, list[str]]]:
    """
    Extract per-op backend order from config.

    Args:
        config: Configuration dict. If None, load from platform config.

    Returns:
        Dict mapping op names to backend order lists.
    """
    if config is None:
        config = load_platform_config()
    if config is None:
        return None

    per_op = config.get('per_op', {})
    if not isinstance(per_op, dict):
        return None

    result = {}
    for op_name, backends in per_op.items():
        if isinstance(backends, list):
            result[op_name] = [str(b) for b in backends]
        elif isinstance(backends, str):
            result[op_name] = [backends]

    return result if result else None


def get_flagos_blacklist(config: Optional[dict] = None) -> Optional[list[str]]:
    """
    Extract FlagOS operator blacklist from config.

    Args:
        config: Configuration dict. If None, load from platform config.

    Returns:
        List of blacklisted FlagOS operator names.
    """
    if config is None:
        config = load_platform_config()
    if config is None:
        return None

    blacklist = config.get('flagos_blacklist', [])
    if isinstance(blacklist, list):
        return [str(op) for op in blacklist]
    return None


def get_oot_blacklist(config: Optional[dict] = None) -> Optional[list[str]]:
    """
    Extract OOT operator blacklist from config.

    Args:
        config: Configuration dict. If None, load from platform config.

    Returns:
        List of blacklisted OOT operator names.
    """
    if config is None:
        config = load_platform_config()
    if config is None:
        return None

    blacklist = config.get('oot_blacklist', [])
    if isinstance(blacklist, list):
        return [str(op) for op in blacklist]
    return None


def get_effective_config() -> dict[str, Any]:
    """
    Get the effective configuration, considering environment variable overrides.

    Priority:
    1. VLLM_FL_CONFIG environment variable (user-specified config file)
    2. Platform-specific config file (auto-detected)
    3. Default config file
    4. Empty config (no restrictions)

    Returns:
        Effective configuration dictionary.
    """
    # Check for user-specified config file
    user_config_path = os.environ.get('VLLM_FL_CONFIG', '').strip()
    if user_config_path and os.path.isfile(user_config_path):
        try:
            with open(user_config_path, 'r', encoding='utf-8') as f:
                config = yaml.safe_load(f)
            if isinstance(config, dict):
                return config
        except Exception:
            pass

    # Load platform config
    platform_config = load_platform_config()
    if platform_config:
        return platform_config

    # Return empty config
    return {}

def get_vendor_device_map() -> dict[str, dict[str, str]]:
    """Load vendor mapping from Python config module.

    Returns:
        Mapping where key is vendor_name and value is
        {"device_type": ..., "device_name": ...}.
    """
    if not isinstance(VENDOR_DEVICE_MAP, dict):
        return {}

    result: dict[str, dict[str, str]] = {}
    for vendor_name, value in VENDOR_DEVICE_MAP.items():
        if not isinstance(vendor_name, str) or not isinstance(value, dict):
            continue

        device_type = value.get("device_type")
        device_name = value.get("device_name")
        if not isinstance(device_type, str) or not device_type:
            continue
        if not isinstance(device_name, str) or not device_name:
            continue

        result[vendor_name] = {
            "device_type": device_type,
            "device_name": device_name,
        }

    return result
