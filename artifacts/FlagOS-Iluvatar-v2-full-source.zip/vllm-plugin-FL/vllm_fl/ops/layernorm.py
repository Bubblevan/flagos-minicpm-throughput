# Copyright (c) 2025 BAAI. All rights reserved.

from typing import Optional, Union
import torch
from vllm.model_executor.layers.layernorm import RMSNorm
from vllm_fl.dispatch import CachedOp

_rms_norm = CachedOp("rms_norm")


class RMSNormFL(RMSNorm):
    def __init__(
        self,
        hidden_size: int,
        eps: float = 1e-6,
        var_hidden_size: Optional[int] = None,
        has_weight: bool = True,
        dtype: Optional[torch.dtype] = None,
    ) -> None:
        super().__init__(hidden_size, eps, var_hidden_size, has_weight, dtype)

    def forward_oot(
        self,
        x: torch.Tensor,
        residual: Optional[torch.Tensor] = None,
    ) -> Union[torch.Tensor, tuple[torch.Tensor, torch.Tensor]]:
        return _rms_norm(self, x, residual)


__all__ = ["RMSNormFL"]
