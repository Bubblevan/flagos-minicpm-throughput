# SPDX-License-Identifier: Apache-2.0
"""Mixed-batch query-tiling experiment; correctness and performance remain unverified.

This adapter reuses the selected native Triton kernel. It increases query rows
per CTA for the validated BF16 GQA layout; pure decode and unvalidated features keep
their original launch. It does not inspect benchmark names or prompt lengths.
"""
import json
import time
from collections import Counter
import os
from pathlib import Path
import torch


def record_runtime(adapter, stage, **details):
    root = os.environ.get('FLAGOS_SESSION_ROOT')
    if not root:
        return
    destination = Path(root) / f'attention-tiling-runtime-{os.getpid()}.json'
    data = dict(pid=os.getpid(), stage=stage, source_file=__file__,
                optimized_launches=adapter.optimized_launches,
                fallback_launches=adapter.fallback_launches, **details)
    temporary = destination.with_suffix('.tmp')
    temporary.write_text(json.dumps(data, indent=2))
    temporary.replace(destination)


class QueryTiledKernel:
    def __init__(self, original, min_average_query_rows=4, min_total_query_rows=128):
        self.original = original
        self.min_average_query_rows = min_average_query_rows
        self.min_total_query_rows = min_total_query_rows
        self.observe_dispatch = os.environ.get("FLAGOS_OBSERVE_DISPATCH") == "1"
        self.dispatch_counts = Counter()
        self.last_profile_write = 0.0
        self.optimized_launches = 0
        self.fallback_launches = 0

    def __getattr__(self, name):
        return getattr(self.original, name)

    def __getitem__(self, grid):
        def launch(*args, **kwargs):
            query = kwargs.get('query_ptr')
            count = kwargs.get('num_seqs', 0)
            eligible = (
                query is not None
                and query.dtype == torch.bfloat16
                and count > 0
                and query.shape[0] >= max(count * self.min_average_query_rows, self.min_total_query_rows)
                and query.shape[0] > count
                and not kwargs.get('IS_3D', True)
                and kwargs.get('HEAD_SIZE') == 128
                and kwargs.get('num_queries_per_kv') == 8
                and kwargs.get('TILE_SIZE') == 32
                and int(kwargs.get('KV_QUANT_MODE', -1)) == 0
                and kwargs.get('USE_CAUSAL', False)
                and kwargs.get('SLIDING_WINDOW') == 0
                and kwargs.get('CHUNK_LOOKBACK', -1) == -1
                and not any(kwargs.get(key, False) for key in (
                    'USE_TD', 'USE_MM_PREFIX', 'USE_SINKS', 'USE_ALIBI_SLOPES',
                    'USE_QQ_BIAS', 'USE_SOFTCAP', 'USE_PER_SEQ_CAUSAL', 'USE_FP8',
                ))
            )
            if eligible:
                # Keep TILE_SIZE=32 and four warps: the KV accumulation order
                # stays identical while eight query tokens share each CTA.
                kwargs = dict(kwargs, BLOCK_M=64, BLOCK_Q=8, num_warps=4)
                selected_grid = (
                    query.shape[0] // 8 + count,
                    kwargs['num_query_heads'] // kwargs['num_queries_per_kv'],
                )
                self.optimized_launches += 1
                if self.optimized_launches == 1:
                    record_runtime(self, 'optimized_kernel_launched',
                                   query_shape=list(query.shape), block_m=64,
                                   block_q=8, kv_tile=kwargs['TILE_SIZE'])
            else:
                selected_grid = grid
                self.fallback_launches += 1
            if self.observe_dispatch and query is not None:
                rows = int(query.shape[0])
                self.dispatch_counts[(rows, int(count), bool(eligible), bool(kwargs.get('IS_3D')))] += 1
                now = time.monotonic()
                if rows > count and now-self.last_profile_write >= 5:
                    self.last_profile_write = now
                    root = os.environ.get('FLAGOS_SESSION_ROOT')
                    if root:
                        destination = Path(root)/f'dispatch-profile-{os.getpid()}.json'
                        temporary = destination.with_suffix('.tmp')
                        temporary.write_text(json.dumps(dict(
                            pid=os.getpid(), at=time.time(), source_file=__file__,
                            scope='Python kernel dispatch only; CUDA graph replay does not invoke this wrapper.',
                            min_average_query_rows=self.min_average_query_rows,
                            min_total_query_rows=self.min_total_query_rows,
                            buckets=[dict(query_rows=k[0],num_seqs=k[1],optimized=k[2],is_3d=k[3],calls=v)
                                     for k,v in self.dispatch_counts.items()]),indent=2))
                        temporary.replace(destination)
            return self.original[selected_grid](*args, **kwargs)
        return launch


def install():
    import vllm.v1.attention.ops.triton_unified_attention as native
    from vllm.platforms import current_platform
    if getattr(current_platform, 'vendor_name', None) != 'iluvatar':
        return False
    if isinstance(native.kernel_unified_attention, QueryTiledKernel):
        return True
    native.kernel_unified_attention = QueryTiledKernel(native.kernel_unified_attention)
    record_runtime(native.kernel_unified_attention, 'installed')
    return True
