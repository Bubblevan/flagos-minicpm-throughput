"""Prepare isolated sources and provenance; does not start any GPU workload."""
from pathlib import Path
import datetime as dt
import hashlib
import importlib.metadata as md
import json
import shutil
import socket
import subprocess

ROOT=Path('/workspace/tokenforge-artifacts/mixed_prefill_20261031_1900')
reservation=json.loads((ROOT/'reservation.json').read_text())
assert dt.datetime.now(dt.timezone.utc).timestamp()<reservation['deadline_epoch']
with socket.socket() as s:assert s.connect_ex(('127.0.0.1',9031))!=0,'Existing model service; inspect first'
gems=Path('/workspace/tokenforge-sources/FlagGems-a7620cc')
v1=Path('/workspace/tokenforge-sources/vllm-plugin-FL-prefill-query-tiling-v1')
tree=subprocess.check_output(['git','-C',str(gems),'write-tree'],text=True).strip()
assert tree=='ddf3c7566aac7d23385a1b10c7c258091ef1d3a7'
relative=Path('vllm_fl/dispatch/backends/vendor/iluvatar/impl/attention_tiles.py')
original_sha=hashlib.sha256((v1/relative).read_bytes()).hexdigest()
assert original_sha=='bb4ad2070e13271eb7c48493fa53e557eea9445c35d93b9de184febf4a0140fd'
candidate=(ROOT/'mixed_attention_tiles.py').read_text(encoding='utf-8-sig')
paths={}
for name,source in [('v1_observe',candidate.replace('min_average_query_rows=4, min_total_query_rows=128','min_average_query_rows=64, min_total_query_rows=0')),('v2',candidate)]:
    target=Path('/workspace/tokenforge-sources')/f'plugin-mixed-20261031-{name}'
    assert not target.exists(),f'Isolated source already exists: {target}; inspect rather than overwrite'
    shutil.copytree(v1,target,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
    (target/relative).write_text(source)
    paths[name]=dict(root=str(target),adapter_sha256=hashlib.sha256((target/relative).read_bytes()).hexdigest(),plugin_head=subprocess.check_output(['git','-C',str(target),'rev-parse','HEAD'],text=True).strip())
versions={}
for name in ('torch','vllm','vllm-plugin-fl','flag-gems','triton','flagtree','evalscope'):
    try:versions[name]=md.version(name)
    except md.PackageNotFoundError:versions[name]=None
vllm_source=Path(md.distribution('vllm').locate_file('vllm/v1/attention/ops/triton_unified_attention.py'))
report=dict(reservation=reservation,versions=versions,source_tree=tree,gems_source=str(gems),v1_source=str(v1),v1_adapter_sha256=original_sha,isolated_sources=paths,
            native_attention_path=str(vllm_source),native_attention_sha256=hashlib.sha256(vllm_source.read_bytes()).hexdigest(),
            hardware=subprocess.check_output(['ixsmi','-q','-d','CLOCK,PERFORMANCE,POWER,UTILIZATION'],text=True,timeout=10),
            installed_sources_untouched=True,preflight_complete=True)
(ROOT/'environment.json').write_text(json.dumps(report,indent=2))
(ROOT/'status.json').write_text(json.dumps(dict(stage='preflight_complete',at=dt.datetime.now(dt.timezone.utc).isoformat())))
print(json.dumps(dict(preflight_complete=True,tree=tree,isolated_sources=paths,versions=versions)))
