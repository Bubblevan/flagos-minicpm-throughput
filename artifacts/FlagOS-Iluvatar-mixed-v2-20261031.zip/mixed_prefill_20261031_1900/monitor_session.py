"""Read-only clocks/process provenance during this reserved experiment."""
import datetime as dt
import json
from pathlib import Path
import subprocess
import time

ROOT=Path(__file__).resolve().parent
END=json.loads((ROOT/'reservation.json').read_text())['deadline_epoch']+30
with (ROOT/'session-telemetry.jsonl').open('a') as output:
    while time.time()<END:
        row=dict(at=time.time())
        try:
            row['stage']=json.loads((ROOT/'status.json').read_text())['stage']
            row['gpu']=subprocess.check_output(['ixsmi','-q','-d','CLOCK,PERFORMANCE,POWER,UTILIZATION'],text=True,timeout=5)
            for name,path in [('cpu_stat','/sys/fs/cgroup/cpu/cpu.stat'),('memory','/sys/fs/cgroup/memory/memory.usage_in_bytes')]:
                try:row[name]=Path(path).read_text().strip()
                except OSError:row[name]=None
            output.write(json.dumps(row)+'\n');output.flush()
            if row['stage']=='optimized_complete_needs_analysis':break
            decision=ROOT/'advancement-decision.json'
            if decision.exists() and not json.loads(decision.read_text()).get('full_validation_started'):break
        except Exception as error:
            output.write(json.dumps(dict(at=time.time(),error=type(error).__name__))+'\n');output.flush()
        time.sleep(10)
